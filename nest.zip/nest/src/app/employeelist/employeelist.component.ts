import { Component, OnInit } from '@angular/core';
import {Employee} from '../employee'
import {EmployeeService} from '../employee.service'
@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
employees:Employee[];
  constructor(private employeeService:EmployeeService) {
   }

  ngOnInit() {
    this.employees=this.employeeService.getAllEmployees();
    console.log(this.employees)
  }
  delete(i:number){
    if(confirm("are you sure ...u want to delete?")){
      this.employeeService.deleteEmployee(i);
console.log("deleted "+i+" onject");
 }
  }
  getTotalCount():number{
    return this.employees.length;
    }
    getMaleCount():number{
    return this.employees.filter(e=>e.gender==='male').length;
    }
    
    getFemaleCount():number{
    return this.employees.filter(e=>e.gender==='female').length;
    }
    recievedvalue:string='all';
    onEmpRadioChange(selectedvalue:string)
    {
      this.recievedvalue=selectedvalue;
    }

}
