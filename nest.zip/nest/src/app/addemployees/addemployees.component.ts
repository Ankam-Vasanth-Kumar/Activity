import { Component, OnInit } from '@angular/core';
import { Employee } from'../employee';
import { EmployeeService } from'../employee.service';


@Component({
  selector: 'app-addemployees',
  templateUrl: './addemployees.component.html',
  styleUrls: ['./addemployees.component.css']
})
export class AddemployeesComponent implements OnInit {
  emp:Employee={
    "eid" :0,"name":'',"salary":0,"gender":' '
    }
    constructor(private employeeService:EmployeeService) { }
   //In this we will use two way binding so initially textbox contains these values
    ngOnInit() {
    }
    add(){
    alert(this.emp.eid+" "+this.emp.name+" "+this.emp.salary+" "+this.emp.gender);
    this.employeeService.addemployee(this.emp);
  this.emp={"eid":0,"name":'',"salary":0,"gender":''}
    }
    
   }
  


