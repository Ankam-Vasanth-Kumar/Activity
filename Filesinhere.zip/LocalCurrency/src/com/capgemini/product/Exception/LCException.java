package com.capgemini.product.Exception;

public class LCException extends Exception{

	public LCException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

		
}
