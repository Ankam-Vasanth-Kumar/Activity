package com.capgemini.product.service;

import java.util.List;
import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;

public interface LocalCurrencyService {

	boolean isNameValid(String productName)throws LCException;

	boolean isPriceValid(double productPrice)throws LCException;

	boolean isQuantityValid(int productQuantity)throws LCException;

	int addProduct(Product product)throws LCException;

	double getPriceInINR(double productPrice, int productQuantity) throws LCException;

	double getConversionCharge(double productPrice)throws LCException;

	List<Product> getAllProducts() throws LCException;

	boolean updateProduct(int productId, Product products)throws LCException;

	boolean delete(int id);

	Product viewById(int custId);

}
