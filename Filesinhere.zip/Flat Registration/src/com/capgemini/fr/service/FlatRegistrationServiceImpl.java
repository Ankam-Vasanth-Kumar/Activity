package com.capgemini.fr.service;

import java.util.Map;

import com.capgemini.fr.bean.FlatRegistration;
import com.capgemini.fr.dao.FlatregistrationDaoImpl;
import com.capgemini.fr.dao.IFlatRegitrationDao;
import com.capgemini.fr.exception.FRException;


public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	
	IFlatRegitrationDao dao=new FlatregistrationDaoImpl();

	@Override
	public boolean isDepositValid(double flatDepositAmount,double flatAmount) throws FRException {
		boolean  depositValidFlag=false;
		if(flatDepositAmount < flatAmount) {
			throw new FRException("Flat Deposit should not be less than Flat Amount");
		}else {
			depositValidFlag=true;
		}
		return depositValidFlag;
	}

	@Override
	public boolean isRentValid(double flatAmount) throws FRException {
		boolean flatAmountFlag=false;
		if(flatAmount < 3000) {
			throw new FRException("Flat amount can't be less than 3000");
		}else {
			flatAmountFlag=true;
		}
		return flatAmountFlag;
	}

	@Override
	public boolean isAreaValid(double flatArea) throws FRException {
		boolean flatAreaFlag=false;
		if(flatArea < 500) {
			throw new FRException("Flat amount can't be less than 500 sq. meters");
		}else {
			flatAreaFlag=true;
		}
		return flatAreaFlag;
	}

	@Override
	public boolean isTypeValid(int flatType) throws FRException {
		boolean flatTypeFlag=false;
		if(flatType!=1 && flatType!=2) {
			throw new FRException("Please enter only 1 & 2 ");
		}else {
			flatTypeFlag=true;
		}
		return flatTypeFlag;
	}

	@Override
	public boolean isIdValid(int ownerId) throws FRException {
		boolean idflag=false;
	if(ownerId!=1 && ownerId!=2 && ownerId!=3) {
		throw new  FRException("Enter Ids from the above list");
	}else {
		idflag=true;
	}
		return idflag;
	}

	@Override
	public int addRegisteredFlat(FlatRegistration registeredFlat) throws FRException {
	
		return dao.addRegisteredFlat(registeredFlat);
	}

	@Override
	public Map<Integer, FlatRegistration> displayAllFlats() throws FRException {
	
		return dao.displayAllFlats();
		
	}

	
	
}
