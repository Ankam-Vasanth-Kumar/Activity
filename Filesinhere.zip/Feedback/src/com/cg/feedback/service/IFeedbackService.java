package com.cg.feedback.service;

import java.util.Map;

import com.cg.feedback.exception.FeedbackException;

public interface IFeedbackService {

	Map<String, Integer> addFeedbackDetails(String name,int rating,String subject) throws Exception;
	Map<String, Integer> getFeedbackReport();
	public boolean validateName(String name) throws FeedbackException;
	public boolean validateRating(int rating) throws FeedbackException;
}
