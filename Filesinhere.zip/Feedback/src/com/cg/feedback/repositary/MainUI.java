package com.cg.feedback.repositary;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import com.cg.feedback.bean.Feedback;
import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.service.FeedbackServiceImpl;
import com.cg.feedback.service.IFeedbackService;



public class MainUI {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {
			
			System.out.println("*** welcome to Feedback***");
			System.out.println("1.Add Feedback");
			System.out.println("2.Print Feedback Report");
			System.out.println("3.exit");

			IFeedbackService service = new FeedbackServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;
			do {
				
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;

					String teacherName = "";
					String subjectName="";
					switch (choice) {

					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter subject name:");
							subjectName = scanner.nextLine();
							try {
								service.validateName(subjectName);
								nameFlag = true;
							} catch (FeedbackException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Teacher name:");
							teacherName = scanner.nextLine();
							try {
								service.validateName(teacherName);
								nameFlag = true;
							} catch (FeedbackException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						int rating = 0;
						boolean ratingFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter rating:");
							try {
								rating = scanner.nextInt();
								service.validateRating(rating);
								ratingFlag = true;
							} catch (InputMismatchException e) {
								ratingFlag = false;
								System.err.println("Cost should be in digits");
							} catch (FeedbackException e) {
								ratingFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!ratingFlag);

						//Feedback feedback = new Feedback(teacherName,rating,subjectName);
						 System.out.println("Feedback added");
					        Map<String, Integer> map=new HashMap<String, Integer>();
					        Feedback feed=new Feedback(teacherName, rating, subjectName);
					        map=service.addFeedbackDetails(teacherName, rating, subjectName);System.out.println(map);
						break;

					case 2:

						 Map<String, Integer> feedbackMap=service.getFeedbackReport();
					        System.out.println(feedbackMap);

						break;

					case 3:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
				
			}while(!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
			
		}while(continueValue);
		
	}

}
