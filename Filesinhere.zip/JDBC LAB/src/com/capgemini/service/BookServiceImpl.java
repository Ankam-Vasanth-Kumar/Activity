package com.capgemini.service;

import com.capgemini.bean.Author;
import com.capgemini.bean.Book;
import com.capgemini.dao.BookDaoImpl;

public class BookServiceImpl implements BookService{
	int row=0;
	BookDaoImpl bookDao=new BookDaoImpl();
	@Override
	public int insertToBook(Book book) {
		row=bookDao.insertToBook(book);
		return row;
	}
	@Override
	public void insertToAuthor(Author author) {
		bookDao.insertToAuthor(author);
		
	}
	@Override
	public Book getBookDetails(String name) {
		return bookDao.getBookDetails(name);
		
	}
	@Override
	public void updatePrice(String name,int amount) {
		bookDao.updatePrice(name,amount);
		
	}

}
