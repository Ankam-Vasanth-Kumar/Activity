package com.capgemini.customerportal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.customerportal.dao.CustomerDAO;
import com.capgemini.customerportal.dao.CustomerDaoImpl;

class CustomerDaoImplTest {
	static CustomerDAO dao;
	Customer customer;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new CustomerDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;

	}
	

	@BeforeEach
	void setUp() throws Exception {
		customer=new Customer(123,"Krish","bangalore",8885401174L);
	}

	@AfterEach
	void tearDown() throws Exception {
		customer=null;
	}

	@Test
	void testAddCustomer() {
	assertEquals(123, dao.addCustomer(customer));
	}

	
	@Test
	void testUpdateCustomer() {
		int custId=dao.addCustomer(customer);
	    customer=new Customer(custId,"amber","delhi",9515766055L);
	    assertTrue(dao.updateCustomer(customer));
	}

	@Test
	void testDeleteCustomer() {
		int custId=dao.addCustomer(customer);
		assertTrue(dao.deleteCustomer(custId));
	}

	

	@Test
	void testGetCustomer() {
		dao.customerList.clear();
		int custId=dao.addCustomer(customer);
		assertNotNull(dao.getCustomer(custId));
	}
	@Test
	void testGetConsumer()
	{
		int custId=dao.addCustomer(customer);
		assertNotNull(dao.getConsumer(custId));
	}
}

	