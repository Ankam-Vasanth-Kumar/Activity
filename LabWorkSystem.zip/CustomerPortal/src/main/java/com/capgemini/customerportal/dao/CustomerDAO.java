package com.capgemini.customerportal.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.customerportal.Customer;

public interface CustomerDAO {
	Map<Integer, Customer>customerList=new HashMap<Integer, Customer>();
	int addCustomer(Customer customer);
	boolean updateCustomer(Customer customer);
	boolean deleteCustomer(int customerID);
	Customer getCustomer(int customerID);
	Map<Integer,Customer>getCustomer();
	Object getConsumer(int custId);
}
