package lab5;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PrintSamples {

	public static void main(String[] args) {
		
	int n=0,m=0;
	
	
	boolean flag=false;
	do {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter N:");
		try {
			flag=true;
		n = scanner.nextInt();
		}catch(InputMismatchException e) {
			flag = false;
			System.err.println("enter digits only\n");
		}
		
		
	} while (!flag);

	
	
	do {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter M:");
		try {
			flag=true;
		m = scanner.nextInt();
		}catch(InputMismatchException e) {
			flag = false;
			System.err.println("enter digits only\n");
		}
		
		
	} while (!flag);
	for(int i=n-1;i!=(n-m-1);i--) {
		
	
		System.out.print(i+"  ");
	
	}
	
	

	}

}
