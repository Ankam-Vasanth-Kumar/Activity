package com.capgemini;

public class LambdaClient {

	public static void main(String[] args) {
		Calculator findmax=(a,b)->a>b?a:b;
		double maximum=findmax.operation(52,98);
		System.out.println("maximum(52,98)is :"+maximum);
		Calculator add=(double a, double b)->a+b;
		Calculator sub=(a,b)->{return a-b;};
		System.out.println("10+20:"+add.operation(10,20));

	}

}
