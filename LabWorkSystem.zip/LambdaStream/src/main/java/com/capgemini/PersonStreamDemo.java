package com.capgemini;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PersonStreamDemo {

	public static void main(String[] args) {
		
List<Person>people=Arrays.asList(
		new Person("Sparrow",25,Gender.MALE),
		new Person("Rani",2,Gender.FEMALE),
		new Person("King",25,Gender.MALE),
		new Person("Amber",30,Gender.MALE),
		new Person("Kiran",40,Gender.MALE),
		new Person("cersi",25,Gender.FEMALE));

people.stream().forEach(System.out::println);
people.stream().filter(p->p.getGender().equals(Gender.FEMALE))
.map(p->p.getName()).forEach(System.out::println);
people.stream().filter(p->p.getGender().equals(Gender.MALE))
.map(p->p.getName()).forEach(System.out::println);



people.stream().filter(p->p.getAge()>18)
.filter(p->p.getGender().equals(Gender.FEMALE))
.map(Person::getName)
.map(String::toUpperCase)
.forEach(System.out::println);


	}

}
