package com.capgemini;
@FunctionalInterface
public interface Greeting {
String greet(String name);
}
