package com.capgemini.ShoppingKart2.service;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ShoppingKart2.DAO.ItemDao;
import com.capgemini.ShoppingKart2.DAO.ItemDaoImpl;
import com.capgemini.ShoppingKart2.Exception.ShoppingExceptions;
import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;

public class CustomerOrderServiceImpl implements CustomerOrderService {

	ItemDao itemdaoobj=new ItemDaoImpl();
	@Override
	public boolean addToCart(Order item) {
		int pid=(int)(Math.random()*1000);
		
		item.setOrderId(pid);
		return itemdaoobj.addItems(pid,item);
	}

	@Override
	public List<Order> printOrderedItems() {
		
		return null;
	}

	@Override
	public HashMap<Integer, Order> getItems() {
		
		return (HashMap<Integer, Order>) itemdaoobj.getItems();
	}

	@Override
	public boolean isNameValid(String name) throws ShoppingExceptions {
		String name1=String.valueOf(name);
		Pattern patternname=Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
}

	@Override
	public boolean isPhoneNoValid(String phone) throws ShoppingExceptions {
		 Pattern patternphone=Pattern.compile("^[6-9]{1}[0-9]{9}$")	;
		 Matcher match=patternphone.matcher(phone);
		 if(match.matches()) {
			 return false;
		 }
			return true;
	}

	
}
