package com.cg;

import static org.junit.Assume.assumeTrue;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

public class DemoTest {
	@Test
	public void m1() {
		System.out.println("Test m1()");
		
	}
	@Disabled
	@Test
	public void m2() {
		System.out.println("test m2()");
		
	}
	@Test
	@RepeatedTest(2)
	public void m3() {
		assumeTrue(1==1);
		System.out.println("tets m3");
		
	}
	

}
