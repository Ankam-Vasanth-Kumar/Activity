package com.cg;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

public class DynamicTestDemo {
	@TestFactory
	Collection<DynamicTest> testmethod(){
		return Arrays.asList(dynamicTest("simple test", ()->assertTrue(true)),
				dynamicTest("adddition",()->assertEquals(30, Math.addExact(10,20))),
				dynamicTest("multiplication", ()->assertEquals(200, Math.multiplyExact(10, 20))));
	}

}
