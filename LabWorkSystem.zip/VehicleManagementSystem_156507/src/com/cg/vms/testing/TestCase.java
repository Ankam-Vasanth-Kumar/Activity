package com.cg.vms.testing;



import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.vms.dao.VehicleDaoImpl;
import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;
import com.cg.vms.service.IVehicleService;
import com.cg.vms.service.VehicleServiceImpl;

public class TestCase {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		HashMap<Integer, Vehicle>addedList=new HashMap<>();
		System.out.println("This is Before Class");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("This is After Class");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("This is Before Method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("This is After method");
	}
	
	@Test
	public void testaddVehicle()
	
	{  Vehicle vehicle=new Vehicle("Honda",50000,"Activa");
	VehicleDaoImpl dao=new VehicleDaoImpl();
	 try {
		assertNotNull(dao.addVehicle(vehicle));
	} catch (VMSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}
	@Test(expected=VMSException.class)
	public void testvalidateVehicleName()throws VMSException{
		IVehicleService obj=new VehicleServiceImpl();
	
		obj.validateVehicleName("honda");
		System.out.println("checking throw");
		
	}
	

	@Test
	public void test() {
		
	}

}
