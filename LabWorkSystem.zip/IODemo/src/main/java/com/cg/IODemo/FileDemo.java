package com.cg.IODemo;

import java.io.File;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) {
		File file1 = new File("src/main/java/com/cg/IODemo/App.java");
		System.out.println(file1.exists()?"file exists":"not exists");
		System.out.println(file1.canRead()?"readable":"not readable");
		System.out.println("is hidden"+file1.isHidden());
		System.out.println("path"+file1.getPath());
		System.out.println("Abs path"+file1.getAbsolutePath());
		try
		{
			System.out.println("canonical path"+file1.getCanonicalPath());
			System.out.println("size"+file1.length());
			System.out.println("last modified"+new Date(file1.lastModified()));
			System.out.println(file1.isDirectory()?"is a folder":"is not a folder");
			File file2= new File("src/main/java/aaa");
			System.out.println("folder created"+file2.mkdir());
			File file3 = new File("src/main/java/aaa/hi.txt");
			System.out.println("file created"+file3.createNewFile());
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
