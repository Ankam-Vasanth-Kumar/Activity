package com.cg;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

public class DataDemo {

	public static void main(String[] args) {
	Date  d1=new Date();
		System.out.println("today date:"+d1);
		Calendar c=Calendar.getInstance();
		System.out.println(d1.hashCode());
		System.out.println(c.get(Calendar.DATE)+"/"+c.get(Calendar.MONTH)+"/"+c.get(Calendar.YEAR));
		SimpleDateFormat sf=new SimpleDateFormat("dd/MM/YYYY");
		System.out.println(sf.format(d1));
		Locale locale=Locale.getDefault();
		int amt=9999999;
		Currency cur=Currency.getInstance(locale);
		System.out.println("current code:"+amt+cur.getCurrencyCode());
		System.out.println("current code:"+amt+cur.getSymbol());
		System.out.println("current code:"+amt+cur.getDisplayName());
		}

}
