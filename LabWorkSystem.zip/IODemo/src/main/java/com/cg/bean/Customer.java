package com.cg.bean;

import java.io.Serializable;

public class Customer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int custid;
	private String username;
	transient private String password;
	private long phone;

	public Customer() {
		super();
	}

	public Customer(int custid, String username, String password, long phone) {
		super();
		this.custid = custid;
		this.username = username;
		this.password = password;
		this.phone = phone;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public static void main(String[] args) {
		
		

	}

}
