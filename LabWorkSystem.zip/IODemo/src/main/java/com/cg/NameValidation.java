package com.cg;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NameValidation {
	static Pattern nameptn=Pattern.compile("^[!@#$%&*()_+-]{1,}$");
	static boolean validateName(String name)
	{
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
	      return true;
		}
		return false;
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter name");
		String name=scanner.next();
		if(validateName(name))
		{
			System.out.println("name is valid");
		}
		else
		{
			System.out.println("not a valid name");
		}
		

	}

}
