package com.cgjavaday1;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
