package com.cgjavaday1;
class Employee{
	private int id;
	private String name;
	private double salary;
	private String designation;
	public void printEmployeeDteails() {
		System.out.println("id is:" + id);
		System.out.println("name is:" + name);
		System.out.println("salary is:" + salary);
		System.out.println("designation is:" + designation);
	}
}

public class EmployeeMain {

	public static void main(String[] args) {
		
	Employee emp=new Employee();
	emp.printEmployeeDteails();
	

	}

}
