package com.capgemini.threads.client;

public class TwoString {
synchronized public void display(String s1,String s2) {
	System.out.println(s1+"=>");
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
				e.printStackTrace();
	}
	System.out.println(s2);
}
}
