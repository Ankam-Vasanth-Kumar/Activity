package com.capgemini.threads.client;

public class PrintThread implements Runnable{
String s1,s2;
TwoString twostring;

	public PrintThread() {
	super();
}

	public PrintThread(String s1, String s2, TwoString twostring) {
		super();
		this.s1 = s1;
		this.s2 = s2;
		this.twostring = twostring;
	}

	public void run() {
		twostring.display(s1, s2);
	}
	public static void main(String[] args) {
		TwoString ts=new TwoString();
		new PrintThread("hello","riya",ts);
	new PrintThread("how","are you?",ts);
			
	}

}
