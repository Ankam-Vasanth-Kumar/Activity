package com.capgemini.BankApplication.Utility;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.BankApplication.bean.Transaction;

public class UtilityClass {
	 public static String name="Baba";
	 public static String password="123456";

	static LocalDate date=LocalDate.now();
	
		
		public static Map<Integer, Transaction>itemlist=new HashMap<>();
		static {
			itemlist.put(12, new Transaction(1234567890,123456,date, "Debit",100));
			itemlist.put(13, new Transaction(1234576891,123457,date, "Debit",200));
			itemlist.put(14, new Transaction(1234587620,123458,date, "Debit",300));
			itemlist.put(15, new Transaction(1234597621,123459,date, "Debit",400));
		}
		public Map<Integer, Transaction> getitems() {
			
			return itemlist;
		}

	


}
