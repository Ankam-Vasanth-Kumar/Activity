package com.capgemini.BankApplication.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;
import com.capgemini.BankApplication.dao.Bankdao;
import com.capgemini.BankApplication.dao.BankdaoImpl;

public class BankServiceImpl implements BankService {
Bankdao bankdaoObj=new BankdaoImpl();

	
	@Override
	public boolean isNameValid(String uname) {
		String name1=String.valueOf(uname);
		Pattern patternname=Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
		
	}

	@Override
	public boolean isPasswordValid(String password) {
		String pword=String.valueOf(password);
		Pattern patternname=Pattern.compile("^[0-9a-zA-Z]{1,}$");
		Matcher match=patternname.matcher(pword);
		if(match.matches()) {
			return false;
	}
		return true;

	}

	@Override
	public boolean isAddressValid(String address) {
		String address1=String.valueOf(address);
		Pattern patternname=Pattern.compile("^[0-9a-zA-Z]{1,}$");
		Matcher match=patternname.matcher(address1);
		if(match.matches()) {
			return false;
	}
		return true;
	}

	@Override
	public boolean isMobileValid(String mobileNo) {
		String mobile=String.valueOf(mobileNo);
		Pattern patternname=Pattern.compile("^[0-9]{10}$");
		Matcher match=patternname.matcher(mobile);
		if(match.matches()) {
			return false;
	}
		return true;
	}

	@Override
	public boolean isAadharValid(long aadhrCardNo) {
	
		String aadhar=String.valueOf(aadhrCardNo);
		Pattern patternname=Pattern.compile("^[0-9]{12}$");
		Matcher match=patternname.matcher(aadhar);
		if(match.matches()) {
			return false;
	}
		return true;
		
	}

	@Override
	public boolean addAccount(Account account) {
		return bankdaoObj.addingAccount(account);
	}

	@Override
	public HashMap<Long, Account> getAccountDetails() {
		
		return bankdaoObj.getDetails();
	}

	@Override
	public HashMap<String, String> getUnamePassword() {
	
		return bankdaoObj.getunamePassword();
	}

	@Override
	public HashMap<Long, Long> ShowBalance() {
		return bankdaoObj.getBalance();

	}

	@Override
	public boolean addTransaction(Transaction tran) {
	return bankdaoObj.addtransaction(tran);
	}

	@Override
	public HashMap<Long, Transaction> getTransaction() {
	
		
		return bankdaoObj.getTransaction();
	}

		
	}


