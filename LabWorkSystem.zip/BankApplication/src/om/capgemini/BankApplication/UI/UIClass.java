package om.capgemini.BankApplication.UI;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.BankApplication.Exception.BankApplicationException;
import com.capgemini.BankApplication.Utility.UtilityClass;
import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;
import com.capgemini.BankApplication.service.BankService;
import com.capgemini.BankApplication.service.BankServiceImpl;


public class UIClass {
	String uname,password,address,mobileNo;
	long aadhrCardNo;
	static long bal=0;
	long accountNo=0;
	long amount;
	 long accno=0;
	Scanner scanner=new Scanner(System.in);
	BankService service=new BankServiceImpl();
	 UtilityClass obj=new UtilityClass();
	
	
	HashMap<String, String> list=new HashMap<>();
	
	HashMap<Long, Long>list2=new HashMap<>();
	
private void Login() {
	
		String name;
		String password2;
		list=service.getUnamePassword();
	
		System.out.println("Enter Name ");
		name=scanner.next();
		System.out.println("Enter Password ");
		password2=scanner.next();
		 Map<Integer, Transaction> itemList1=obj.getitems();
if(   (list.containsKey(name)&&list.containsValue(password2))   ||(name.equals(UtilityClass.name)&&password2.equals(UtilityClass.password))) {
			System.out.println(list.containsValue(password2));
			System.out.println("************************Welcome to Capgemini****************************");
			int choice = 2;
			boolean flag = true;
			String ch = null;
	        do {
			System.out.println("1.ShowBalance             2.Deposit\n3.WithDraw                 4.MoneyTransfer\n5.PrintTransaction       0.Exit");
			try {
				Scanner scanner1=new Scanner(System.in);
				choice = scanner1.nextInt();

				switch (choice) {
				case 1:
					list2=service.ShowBalance();
					
					System.out.println("Your Account Balace:"+bal);
					flag=false;
					break;
				
				case 2:
			      System.out.println("enter money");
			      Scanner scanner3=new Scanner(System.in);
			      amount=scanner3.nextLong();
			      bal=bal+amount;
			      LocalDate date=LocalDate.now();
			      accno=accountNo;
			      Transaction tran=new  Transaction(accountNo,accno,date,"Credit",amount);
					 boolean flag1=service.addTransaction(tran);
						if(flag1)
							System.out.println("  Money Deposited..................");
						else
							System.out.println("unable to create account");
			      
					flag=false;
					break;
				case 3:
					   System.out.println("enter money to withdraw");
				      Scanner scanner2=new Scanner(System.in);
				      amount=scanner2.nextLong();
				      bal=bal-amount;
				      LocalDate date1=LocalDate.now();
				      accno=accountNo;
				      Transaction tran1=new  Transaction(accountNo,accno,date1,"Debit",amount);
						 boolean flag11=service.addTransaction(tran1);
							if(flag11)
								System.out.println("  Money Withdrawn Successfully.................");
							else
								System.out.println("unable to create account");
				      
			          flag=false;
						break;
				case 4:
					System.out.println("enter account No of receiver:\n");
					 Scanner scanner4=new Scanner(System.in);
					 accno=scanner4.nextLong();
					 System.out.println("enetr money");
					 long money=scanner4.nextLong();
					 LocalDate date11=LocalDate.now();
					 Map<Long, Long>accountsList=new HashMap<>();
					 accountsList=service.ShowBalance();
					
					 bal=bal-money;
					 Map<Integer, Transaction> itemList2=obj.getitems();
					
					
					 if(itemList2.containsKey(accno));
					 {
						 Transaction tran2=new  Transaction(accountNo,accno,date11,"Debit",money);
						 boolean flag111=service.addTransaction(tran2);
							if(flag111)
								System.out.println("  Money Transferred Successfully..................... ");
							else
								System.out.println("unable to create account");
						
					 }
					 break;
				case 5:
					   System.out.println("printing transaction");
				      HashMap<Long, Transaction>hs=service.getTransaction();
				      Iterator<Transaction>it=hs.values().iterator();
				      System.out.println("From Account           To Account         Date        TransactionType         Amount");
				      System.out.println("---------------------------------------------------------------------------------------");
				      
						while(it.hasNext())
						{
							System.out.println(it.next());
						}
				      break;
						
					 
				case 0:System.out.println("***********************Come back Soon..!!********************************");
					System.exit(0);
				default:
					System.out.println("Please enter the  Correct Choice ");
					flag=true;

				}
				System.out.println("Press Y to continue");
				Scanner scan=new Scanner(System.in);
				ch = scan.nextLine();
				
				
			} catch (InputMismatchException e) {
				System.err.println("Please enter 1 or 0 only");
			}
	        }while(ch.equalsIgnoreCase("y"));
			
			
			
			
		}
else {
	System.out.println("invalid credentials");
}
}
		
	
	private void Register() {
		
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Name");
			uname=scanner.nextLine();
			try {
				flag=service.isNameValid(uname);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("first letter in the name should be capital throws");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("set Password");
			password=scanner.nextLine();
			try {
				flag=service.isPasswordValid(password);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);		
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter address");
			address=scanner.nextLine();
			try {
				flag=service.isAddressValid(address);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("enter mobile number");
			mobileNo=scanner.nextLine();
			try {
				flag=service.isMobileValid(mobileNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter aadhar number");
			aadhrCardNo=scanner.nextLong();
			try {
				flag=service.isAadharValid(aadhrCardNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		accountNo=(long)(Math.random()*1000000000);
	
		Account account=new Account(uname,password,address,mobileNo,aadhrCardNo,0,accountNo);

		boolean flag1=service.addAccount(account);
		if(flag1) {
			System.out.println("  account created successfully");
			System.out.println("enter login details to access your account");
			Login();
		}
		else
			System.out.println("unable to create account");
		
	}

	public static void main(String[] args) {
		UIClass clientUI = new UIClass();
		Scanner scanner=new Scanner(System.in);
		 LocalDate date=LocalDate.now();
		 System.out.println("Date:"+date);
		System.out.println("--------------------Welcome to the Capgemini Bank-------------------------------");
		int choice = 2;
		boolean flag = true;
		String ch = null;
        do {
		System.out.println(" 1.Register \n 0.Exit");
		try {
			Scanner scanner1=new Scanner(System.in);
			choice = scanner1.nextInt();

			switch (choice) {
			case 1:
				clientUI.Register();
				flag=false;
				break;
			case 2:
				clientUI.Login();
				break;
			
			case 0:System.out.println("Come back Soon..!!");
				System.exit(0);
			default:
				System.out.println("Please enter the  Correct Choice ");
				flag=true;

			}
			System.out.println("Press Y to continue");
			Scanner scan=new Scanner(System.in);
			ch = scan.nextLine();
			
			
			
		} catch (InputMismatchException e) {
			System.err.println("Please enter correct only");
		}
        }while(ch.equalsIgnoreCase("y"));

	}

	

	
}
