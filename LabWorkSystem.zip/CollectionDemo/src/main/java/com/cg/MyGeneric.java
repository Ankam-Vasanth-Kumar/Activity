package com.cg;

public class MyGeneric<T extends Number> {
	private void display(T a,T b) 
	{
		System.out.println("A="+a);
		System.out.println("B="+b);
	}
	public static void main(String[] args)
	{
		MyGeneric<Integer> mgc1=new MyGeneric<Integer>();
		mgc1.display(10, 20);
		MyGeneric<Double> mgc2=new MyGeneric<Double>();
		mgc2.display(10.34, 20.56);

}
}
