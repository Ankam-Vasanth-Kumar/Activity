package com.cg;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Vector;

public class ListDemo {
	public static void main(String[] args)
	{
	   LinkedList<Integer>list2=new LinkedList<Integer>();
	    list2.add(10);
	    list2.add(new Integer(20));
	    list2.add(30);
	    list2.add(40);
	    list2.add(50);
	    System.out.println("list2:"+list2);
	    list2.addFirst(7);
	    list2.addLast(21);
	    System.out.println("list2:"+list2);
	    list2.removeLastOccurrence(new Integer(21));
	    System.out.println("list2:"+list2);
	    list2.offer(56);
	    list2.offer(66);
	    System.out.println("list2:"+list2);
	    list2.poll();
	    System.out.println("list2:"+list2);
	    Iterator<Integer>it=list2.iterator();
	    System.out.println("Iterator  below");
	    while(it.hasNext())
	    {
	    	System.out.println(it.next()+" ");
	    }

	    System.out.println("for each below");
	    for(Integer i:list2) {
	    	System.out.println(i+" ");
	    }
	    Vector<String>v=new Vector<>(3,2);
	    System.out.println("\ncapacity:"+v.capacity());
	    System.out.println("size:"+v.size());
	    v.add("java");
	    v.add("python");
	    v.add("machine learning");
	    v.add("angular js");
	    v.add("spring");
	    v.add("695464");
	    System.out.println(v);
	    System.out.println("\ncapacity:"+v.capacity());
	    System.out.println("size:"+v.size());
	    Enumeration<String>en=v.elements();
	    while(en.hasMoreElements())
	    {
	    	System.out.print(" "+en.nextElement());
	    }
	    Stack<Integer>stack=new Stack();
	    stack.add(11);
	    stack.push(22);
	    stack.push(22);
	    System.out.println("stack"+stack);
	    System.out.println("top value"+stack.peek());
	    stack.pop();
	    System.out.println("after pop+stack");
	    
	    
	     
	    
}
}
