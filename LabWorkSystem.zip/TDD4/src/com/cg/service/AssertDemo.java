package com.cg.service;

import java.util.Scanner;

public class AssertDemo {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		assert(n>0):"nshould be +ve";
		System.out.println("entered value is:"+n);
	}

}
