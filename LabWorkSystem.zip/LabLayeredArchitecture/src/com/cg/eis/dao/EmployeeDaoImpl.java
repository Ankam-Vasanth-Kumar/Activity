package com.cg.eis.dao;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public boolean addEmployee(int empid, Employee employee) {
		empList.put(empid, employee);
		return true;
	}

	@Override
	public HashMap<Integer, Employee> getDetails() {
		
		return empList;
	}

	
}
