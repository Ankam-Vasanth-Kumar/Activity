package com.cg.eis.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDao;
import com.cg.eis.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {
	
EmployeeDao daoObj=new EmployeeDaoImpl();
	@Override
	public boolean isNameValid(String name) {
		String name1=String.valueOf(name);
		Pattern patternname=Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
	}

	@Override
	public boolean isEmployeeIDValid(int empid) {
		String emp=String.valueOf(empid);
		Pattern pattern=Pattern.compile("^[0-9]{4,}$");
		Matcher match=pattern.matcher(emp);
		if(match.matches()) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isDesignationValid(String designation) {
		String name1=String.valueOf(designation);
		Pattern patternname=Pattern.compile("^[a-z]{5,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
	}

	@Override
	public String getScheme(long salary, String designation) {
		String type = null;
		if((salary>5000&&salary<20000)&&designation.equalsIgnoreCase("SystemAssociate"))
		type="Scheme C";
		else if((salary>20000&&salary<40000)&&designation.equalsIgnoreCase("Programmer"))
		 type="Scheme B";
		else if((salary>=40000)&&designation.equalsIgnoreCase("Manager"))
			 type="Scheme A";
		else if((salary<5000)&&designation.equalsIgnoreCase("Clerk"))
			 type="No Scheme";
		
		
		return type;
	}

	@Override
	public boolean isSalaryValid(long salary) {
		String emp=String.valueOf(salary);
		Pattern pattern=Pattern.compile("^[0-9]{4,}$");
		Matcher match=pattern.matcher(emp);
		if(match.matches()) {
			return false;
		}
		return true;
	}

	@Override
	public boolean addEmployeeDetails(int empid, Employee employee) {
	return daoObj.addEmployee(empid,employee);
	}

	@Override
	public HashMap<Integer, Employee> getEmployeeDetails() {
		return daoObj.getDetails();
	}

	

	
}
