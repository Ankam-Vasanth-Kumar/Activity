package com.cg.eis.service;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	boolean isNameValid(String name);

	boolean isDesignationValid(String designation);

	String getScheme(long salary, String designation);

	boolean isSalaryValid(long salary);

	boolean isEmployeeIDValid(int empid);

	boolean addEmployeeDetails(int empid, Employee employee);

	HashMap<Integer, Employee> getEmployeeDetails();

}
