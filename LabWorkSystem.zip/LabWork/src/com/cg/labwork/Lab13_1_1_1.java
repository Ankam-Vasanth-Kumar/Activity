package com.cg.labwork;

public class Lab13_1_1_1 implements Lab13_1_1 {

	@Override
	public int power(int x, int y) {
		return 0;
		
	}

}
