package com.cg.labwork;

public interface Lab13_2 {
String AddSpace(String name);
}
