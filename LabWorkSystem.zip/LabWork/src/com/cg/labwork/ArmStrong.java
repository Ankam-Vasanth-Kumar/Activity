package com.cg.labwork;

import java.util.Scanner;

public class ArmStrong {
	public int checkArmstrong(int array[]) {
		int n;
		int temp[]=new int[array.length];
		int counting=0;

		for(int i=0;i<array.length;i++)
		{
						int remainingNumber=array[i];
				        n=remainingNumber;
					    
					    int count=0;
						while(remainingNumber>0)
						{
							remainingNumber=remainingNumber/10;
							count++;
					    }
					remainingNumber=n;
					                           if(count==1)
						                        return 1;
							else
							{int var=0;
								while(remainingNumber>0)
								{
									int k=1;
									int number=count;
									int remainder=remainingNumber%10;
									remainingNumber=remainingNumber/10;
													while(number>0)
													{
														
														k=k*remainder;
											            number--;
													}
									var=var+k;
								
							    }
								if(var==n)
								{
									System.out.println("var is armstrong"+var);
									counting++;
								}
									
								else
								{
									System.out.println("var is  not armstrong"+var);
									counting=counting;
								}
								
		                     }			
		}
		return counting;
	}

	public static void main(String[] args) {
		ArmStrong obj = new ArmStrong();
		System.out.println("enter n");
		Scanner scanner = new Scanner(System.in);
		int size=scanner.nextInt();
		int array[]=new int[size];
		for(int i=0;i<size;i++)
			array[i]=scanner.nextInt();
		int result = obj.checkArmstrong(array);
		

			System.out.println("Armstrong numbers "+result);
	

	}

}
