package com.cg.labwork;

import java.util.Scanner;

public class Sum {
public int calculateSum(int n) {
	int sum=0;
	for(int i=3;i<=n;i++) {
		if((i%3)==0||(i%5==0))
		{
			sum=sum+i;
		}
	}
	return sum;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sum obj = new Sum();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		System.out.println("n:"+n);
		System.out.println("sum:" + obj.calculateSum(n));

	}

}
