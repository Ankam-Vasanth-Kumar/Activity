package com.cg.labwork;

import java.util.Scanner;

public class lab4 {
	public int sumOfCubes(int number)
	{   
		int result=0, remainingNumber=number;
	    int count=0;
		while(remainingNumber>0)
		{
			remainingNumber=remainingNumber/10;
			count++;
	    }
		remainingNumber=number;
		while(count>0)
		{
			int remainder=remainingNumber%10;
			result=result+(remainder*remainder*remainder);
			remainingNumber=remainingNumber/10;
			count--;
		}
	
	
		return result;
	}

	public static void main(String[] args) {
		lab4 obj = new lab4();
		System.out.println("enter a number");
		Scanner scanner = new Scanner(System.in);
		int num=scanner.nextInt();
		System.out.println("sum of cubes:"+obj.sumOfCubes(num));

	}

}
