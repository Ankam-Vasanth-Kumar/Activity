package com.cg.labwork;

import java.util.Scanner;

public class lab3_4 {
public void	countCharacters(char[] array2)
{    int flag=1;
	int length=array2.length;
	   for(int i=0;i<array2.length;i++)
	   {
					for(int j=i-1;j>=0;j--)
					{
						
					if(array2[i]==array2[j])
					{
						flag=0;
	                     break;				
					}
					else
						flag=1;
					}
					if(flag==1)
					{ 
						int count=0;
						for(int k=i;k<array2.length;k++)
						{
							if(array2[i]==array2[k])
								count++;
							
								
						}
						System.out.println(array2[i]+":"+count);
					}
					else
					{
						
					}
	   }
	   
	   
   
}

	public static void main(String[] args) {
		lab3_4 obj=new lab3_4();
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter name");
		String word=scanner.nextLine();
		char[] array=word.toCharArray();
		obj.countCharacters(array);
		

	}

}
