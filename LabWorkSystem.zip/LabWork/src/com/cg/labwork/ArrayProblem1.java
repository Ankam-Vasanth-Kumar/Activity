package com.cg.labwork;

import java.util.Scanner;

public class ArrayProblem1 {
	public static int[] reverseElements(int array[]) {
		int n;
		int temp[]=new int[array.length];

		for(int i=0;i<array.length;i++)
		{
			int remainingNumber=array[i];
	        n=remainingNumber%10;
			while(remainingNumber>0)
			{
				if(n>0)
				{
					
					n=remainingNumber%10;
					remainingNumber=remainingNumber/10;
					temp[i]=temp[i]*10+n;
				}
			
		    }
	}
		return temp;
	}

	public static void main(String[] args) {
		int size;
		ArrayProblem1 obj = new ArrayProblem1();
		System.out.println("enter size");
		Scanner scanner = new Scanner(System.in);
		size = scanner.nextInt();
		int array[]=new int[size];
		for(int i=0;i<size;i++)
			array[i]=scanner.nextInt();
		int output[] = reverseElements(array);
		for(int i=0;i<output.length;i++)
			System.out.println(output[i]);

	}

}
