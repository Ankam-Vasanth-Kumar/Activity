package com.cg.labwork;

public interface Lab13_3 {
	boolean validate(String uname,String password);
	

}
