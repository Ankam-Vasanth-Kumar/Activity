package com.cg.Lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread implements Runnable {

	@Override
	public void run() {
	try {
		FileInputStream fis=new FileInputStream("src/source.txt");
		FileOutputStream fout=new FileOutputStream("src/target.txt");
		int i=0;
		while(i!=-1) {
			i=fis.read();
			fout.write(i);
		}
		System.out.println("data copied from Sorce.txt To Target.txt");
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
		
		e.printStackTrace();
	}
		
	}

}
