package com.cg.eis.exception;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeException {
	
	
		static Pattern nameptn=Pattern.compile("^[0-9]*$");
		public static void main(String[] args) {
			Scanner scanner=new Scanner(System.in);
			EmployeeException obj=new EmployeeException();
			try {
			
			System.out.println("enter salary");
			int salary=scanner.nextInt();
			
			if(salary<3000)
				throw new ValidateSalary();
			else
			{
				System.out.println("");
			}
		}
			catch(ValidateSalary e)
			{
				System.out.println("salary is lessthan 3000");
			}

		}

	}
	class ValidateSalary extends Exception {
		public ValidateSalary() {
			
		}

	}
