package com.cg.labwork;

import java.util.Arrays;
import java.util.Scanner;

public class Lab8_5 {
	void checkString(String string) {
		System.out.println("string is:"+string);
		char[] compare=string.toCharArray();
		char[]chaar=string.toCharArray();
		int flag=1,j=1;
		Arrays.sort(chaar);
		String obj=new String(chaar);
		
			if(string.equals(obj))
				flag=0;
			else
				flag=1;
		
		
		
		if(flag==0)
			System.out.println("string is  +ve");
		else
			System.out.println("string is not +ve");
		
	}

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Lab8_5 obj=new Lab8_5();
		String word=scanner.next();
		obj.checkString(word);
		
	}

}
