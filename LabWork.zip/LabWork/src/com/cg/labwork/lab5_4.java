package com.cg.labwork;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class lab5_4 {
	static Pattern nameptn=Pattern.compile("^[a-zA-Z]*$");
	static boolean validateName(String name)
	{
		Matcher match=nameptn.matcher(name);
		if(match.matches())
		{
	      return true;
		}
		return false;
	}
	

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		lab5_4 obj=new lab5_4();
		try {
		System.out.println("enter first name");
		String name1=scanner.nextLine();
		System.out.println("enter middle name");
		String name2=scanner.nextLine();
		System.out.println("enter last name");
		String name3=scanner.nextLine();
		String name=name1+name2+name3;
		if(name1.isEmpty()||name3.isEmpty())
			throw new NotValidName();
		else
		{
			System.out.println(lab5_4.validateName(name));
		}
	}
		catch(NotValidName e)
		{
			System.out.println("not blank");
		}
	}
	}

class NotValidName extends Exception {
	public NotValidName() {
		
	}

}


	
		

		



