package com.cg.labwork;

import java.util.Scanner;

public class arrayReverseSort {
	
		public static int[] reverseElements(int array[]) {
			int n;
			int temp[]=new int[array.length];

			for(int i=0;i<array.length;i++)
			{
						int remainingNumber=array[i];
				        n=remainingNumber%10;
						while(remainingNumber>0)
						{
							if(n>0)
							{
								
								n=remainingNumber%10;
								remainingNumber=remainingNumber/10;
								temp[i]=temp[i]*10+n;
							}
						
					    }
		    }
			int temp2=0;
			
			for(int i=0;i<temp.length;i++) 
			{
				for(int j=0;j<temp.length;j++) 
				{
					if(array[i]<array[j])
					{
						temp2=temp[i];
						temp[i]=temp[j];
						temp[j]=temp2;
					}
				}
			}
			
			
			return temp;
		}

		public static void main(String[] args) {
			int size;
			arrayReverseSort obj = new arrayReverseSort();
			System.out.println("enter size");
			Scanner scanner = new Scanner(System.in);
			size = scanner.nextInt();
			int array[]=new int[size];
			for(int i=0;i<size;i++)
				array[i]=scanner.nextInt();
			int output[] = reverseElements(array);
			for(int i=0;i<output.length;i++)
				System.out.println(output[i]);

		}

	}



