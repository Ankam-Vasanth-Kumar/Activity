package com.cg.labwork;

public interface Lab13_1_1 {
	int power(int a,int b);

}
