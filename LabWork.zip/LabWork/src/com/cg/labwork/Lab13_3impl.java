package com.cg.labwork;

import java.util.Scanner;

public class Lab13_3impl {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name :");
		String name=sc.nextLine();
		System.out.println("Enter password :");
		String pword=sc.nextLine();
		Lab13_3 obj=(uname,password)->{
			String name2="abc";
			String password1="1234";
			if(uname.equals(name2)&&password.equals(password1)) {
				return true;
			}
			else {
				return false;
			}
			
			
		};
		System.out.println("credentials are:"+obj.validate(name, pword) );
		
		
	}

}
