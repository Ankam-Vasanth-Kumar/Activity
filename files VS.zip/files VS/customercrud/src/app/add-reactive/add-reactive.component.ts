import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-reactive',
  templateUrl: './add-reactive.component.html',
  styleUrls: ['./add-reactive.component.css']
})
export class AddReactiveComponent implements OnInit {
customer:Customer={"id":0,"name":'',"email":'',"phone":0};
custForm:FormGroup;
status:string="Invalid";
  constructor(private formBuilder:FormBuilder,private service:CustomerService,private router:Router ) { }

  ngOnInit() {
    this.custForm=this.formBuilder.group({
      id:['',Validators.required,'',Validators.pattern('[0-9]{2,}')],
      name:['',Validators.required,'',Validators.pattern('[a-zA-Z]{5,}')],
      email:['',Validators.required,'',Validators.email],
      phone:['',Validators.required,'',Validators.pattern('[0-9]{10,}')],
    });
  }
  addreactive(){
    this.customer=this.custForm.value;
    if(this.custForm.invalid){
      status="Invalid";
      return;
    }
    else{
      this.service.addCustomer(this.customer).subscribe((data)=>{
        this.router.navigate(['listcustomer']);
      })
    }
  }

}
