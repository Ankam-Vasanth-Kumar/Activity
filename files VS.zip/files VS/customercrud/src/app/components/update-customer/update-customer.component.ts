import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/service/customer.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
customerData:Customer={"id":0,"name":'',"email":'',"phone":0};
  constructor(private customerService:CustomerService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
this.route.params.subscribe(
  (params)=>{this.customerService.getCustomer(params['id']).subscribe((result)=>{this.customerData=result;})});
  }


  update(){
    console.log(this.customerData.name);
    this.customerService.updateCustomer(this.customerData).subscribe((data)=>{this.router.navigate(['listcustomer'])})
  }

  }



