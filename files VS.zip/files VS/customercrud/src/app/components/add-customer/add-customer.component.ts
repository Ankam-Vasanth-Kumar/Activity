import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/service/customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {
customerData:Customer={"id":0,"name":'',"email":'',"phone":0}
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    console.log(this.customerData.name);
    this.customerService.addCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['listcustomer']);}
    );
  }

}
