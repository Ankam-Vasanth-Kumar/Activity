import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { CustomerlistComponent } from './components/customerlist/customerlist.component';
import { AddCustomerComponent } from './components/add-customer/add-customer.component';
import { UpdateCustomerComponent } from './components/update-customer/update-customer.component';
import{ FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule } from '@angular/common/http';
import{ CustomerService } from './service/customer.service';
import { AddReactiveComponent } from './add-reactive/add-reactive.component';
import { LoginComponent } from './login/login.component';
import { ChangetextDirective } from './changetext.directive';
import { MultiplierPipe } from './multiplier.pipe';
import { SearchComponent } from './search/search.component';
import { ShowsearcheddataComponent } from './showsearcheddata/showsearcheddata.component';
@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    ContactComponent,
    CustomerlistComponent,
    AddCustomerComponent,
    UpdateCustomerComponent,
    AddReactiveComponent,
    LoginComponent,
    ChangetextDirective,
    MultiplierPipe,
    SearchComponent,
    ShowsearcheddataComponent
  ],
  imports: [
    FormsModule,ReactiveFormsModule,HttpClientModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
