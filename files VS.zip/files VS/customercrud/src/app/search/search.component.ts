import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
customer:Customer[];
searchItem:string='';
searchedData:Customer[];
  customers: string;


  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.service.getAllCustomers().subscribe(
      (data:Customer[])=>{this.customer=data;
      console.log("all"+this.customers)});
  }
  search(value:string){
    this.searchedData=this.customers.filter(
      customer=>customer.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
      this.service.setSearcheddata(this.searchedData);
  }

}
