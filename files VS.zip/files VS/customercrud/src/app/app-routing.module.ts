import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerlistComponent } from './components/customerlist/customerlist.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { AddCustomerComponent } from './components/add-customer/add-customer.component';
import { UpdateCustomerComponent } from './components/update-customer/update-customer.component';
import { AddReactiveComponent } from './add-reactive/add-reactive.component';
import { LoginComponent } from './login/login.component';
import{ AuthGuard } from './auth.guard';
import { SearchComponent } from './search/search.component';
import { ShowsearcheddataComponent } from './showsearcheddata/showsearcheddata.component';


const routes: Routes = [
  {path:'',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'home',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'listcustomer',component:CustomerlistComponent},
  {path:'about', component:AboutComponent},
  {path:'contact', component:ContactComponent},
  {path:'add', component:AddCustomerComponent,canActivate:[AuthGuard]},
  {path:'listcustomer/update/:id', component:UpdateCustomerComponent},
  {path:'addReactive',component:AddReactiveComponent},
  {path:'login',component:LoginComponent},
  {path:'search',component:SearchComponent},
  {path:'showsearch',component:ShowsearcheddataComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
