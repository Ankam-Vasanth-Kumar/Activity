import { Injectable } from '@angular/core';
import {Employee} from './employee'
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:Employee[]=[ 
  {eid:113,name:"priya",salary:8798.765,gender:"female"},
  {eid:114,name:"riya",salary:87900.765,gender:"female"},
  {eid:113,name:"piya",salary:8888.765,gender:"female"}
  ]
  constructor() { }
  getAllEmployees():Employee[]{
    return this.employees;
  }
  addemployee(employee:Employee){
    this.employees.push(employee);
    return true;
  }
  deleteEmployee(i:number){
    this.employees.splice(i,1);
  }
}
