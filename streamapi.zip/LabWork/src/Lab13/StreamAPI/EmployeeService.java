package Lab13.StreamAPI;

import java.util.Map;
import java.util.Set;

public class EmployeeService implements IEmployeeService{
	IEmployeeDAO employeeDao=new EmployeeDAIO();
	public Set<Double> sumOfSal() {
		return employeeDao.sumOfSal();
		
	}
	public Map<String,Long> getCountByDept() {
		return employeeDao.getCountByDept();
		
	}

}
