package Lab13.StreamAPI;

import java.util.Map;
import java.util.Set;

public interface IEmployeeDAO {

	public Set<Double> sumOfSal();

	public Map<String,Long> getCountByDept();

}
