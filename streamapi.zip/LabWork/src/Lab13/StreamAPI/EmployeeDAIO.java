package Lab13.StreamAPI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeDAIO implements IEmployeeDAO{

	@Override
	public Set<Double> sumOfSal() {
		Map<Integer,Employee> employeDetails=EmployeeRepository.getEmployeeDetails();
		Stream<Double> employeeStream = null;
		List<Employee> employeeList=new ArrayList<>();
		for (Map.Entry m:employeDetails.entrySet()) {
			Employee employee=(Employee) m.getValue();
			employeeList.add(employee);
			double salary=employee.getSalary();
			employeeStream=Stream.of(salary);
		}
		Set<Double> map=employeeStream.map(a->a+a).collect(Collectors.toSet());
		return map;
	}

	@Override
	public Map<String,Long> getCountByDept() {
		Map<String,Long> countMap=new HashMap<>();
		Map<Integer,Employee> employeDetails=EmployeeRepository.getEmployeeDetails();
		for (Map.Entry map:employeDetails.entrySet()) {
			Employee employee=(Employee) map.getValue();
			Department department=employee.getDepartment();
			String name=department.getName();
			List<Department> employeeList=new ArrayList<>();
			employeeList.add(department);
			Long count=employeeList.stream().filter(i->i.getDepartmentId()==i.getDepartmentId()).collect(Collectors.counting());
			countMap.put(name, count);
		}
		return countMap;
	}

}
