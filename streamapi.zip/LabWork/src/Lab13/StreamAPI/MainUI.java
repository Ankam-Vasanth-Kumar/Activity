package Lab13.StreamAPI;

import java.util.Map;
import java.util.Set;

public class MainUI {
	static EmployeeService service=new EmployeeService();
	public static void main(String[] args) {
		Set<Double> set=service.sumOfSal();
		System.out.println("Sum of the salary :"+set);
		Map<String,Long> count=service.getCountByDept();
		System.out.println(count);
	}
}
