package Lab13.StreamAPI;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
public class EmployeeRepository {
	static Map<Integer,Employee> employeeDetails=new HashMap<>();
	
	static {
		LocalDate l1=LocalDate.parse("2019-06-20");
		
		Department d1=new Department(10,"CSE",845);
		employeeDetails.put(1234,new Employee(1234,"Ramya","Vagdevi","rvagdevi699@gmail.com","8096368415",l1,"software",25000,854,d1));
		LocalDate l2=LocalDate.parse("2015-05-25");
		Department d2=new Department(20,"EEE",456);
		employeeDetails.put(7589,new Employee(7589,"Manikanta","Anirudh","salagrama94anirudh@gmail.com","9951054145",l2,"software",65000,456,d2));
	}

	public static Map<Integer, Employee> getEmployeeDetails() {
		return employeeDetails;
	}

	public static void setEmployeeDetails(Map<Integer, Employee> employeeDetails) {
		EmployeeRepository.employeeDetails = employeeDetails;
	}
	
}
