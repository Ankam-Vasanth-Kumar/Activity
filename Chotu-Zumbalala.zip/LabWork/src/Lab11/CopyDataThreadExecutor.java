package Lab11;
/*
 * Exercise 1: Implement the Multithreading Assignments using Executor, ExecutorService interface .
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CopyDataThreadExecutor implements Executor {
	static int letter = 0;
	static int i = 0;
	private String source;
	private String target;
	static FileInputStream fin = null;
	static FileOutputStream fout = null;

	 ExecutorService executor=Executors.newSingleThreadExecutor();
	
	 
	public CopyDataThreadExecutor() {
		super();
		}
	


	public CopyDataThreadExecutor(String source, String target) {
		super();
		this.source = source;
		this.target = target;
	}

   void runnable1() {
      Runnable runnable=()->{
    	  try {
  			fin = new FileInputStream(source);
  			fout = new FileOutputStream(target);
  			while (i != -1) {
  				try {
  					i = fin.read();
  					fout.write(i);
  					
  					letter++;
  					if (letter == 10) {
  						letter = 0;
  						Thread.sleep(5000);
  						/*Timer timer = new Timer("MyTimer");
  						timer.scheduleAtFixedRate(new CopyDataThread(), 30, 3000);
  					*/}
  					System.out.print((char) i);
  					
  				
  				} catch (IOException e1) {
  					e1.printStackTrace();
  				} catch (InterruptedException e2) {
  					e2.printStackTrace();
  				}
  			
  				
  	}
  		}catch (IOException e) {
  			e.printStackTrace();
  		}
      };
     execute(runnable);
     
   }

	@Override
	public void execute(Runnable command) {
		executor.execute(command);
	}
		
		
	

}
