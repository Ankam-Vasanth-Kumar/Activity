package com.cg.labbook2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class AuthorBook {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Book1> list=new ArrayList<Book1>();
	
	public List<Book1> getList() {
		return list;
	}
	public void setList(List<Book1> list) {
		this.list = list;
	}
	public AuthorBook() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AuthorBook(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
