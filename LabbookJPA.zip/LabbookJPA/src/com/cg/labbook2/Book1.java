package com.cg.labbook2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cascade;
@Entity
public class Book1 {
	@Id
	@GeneratedValue
	private int id;
	private  String title;
	private double price;
	@ManyToOne
	private AuthorBook author;
	
	
	public AuthorBook getAuthor() {
		return author;
	}
	public void setAuthor(AuthorBook author) {
		this.author = author;
	}
	public Book1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Book1(int id, String title, double price) {
		super();
		this.id = id;
		this.title = title;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book1 [id=" + id + ", title=" + title + ", price=" + price + ", author=" + author + "]";
	}
	

}

