package com.cg.labbook2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.labbook.Author;

public class MainL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Id");
		int id = sc.nextInt();

		Book1 book = new Book1();
		book.setTitle("Romeo Juliet");
		book.setPrice(600);
		Book1 book1 = new Book1();
		book1.setTitle("Ramayana");
		book1.setPrice(1500);
		AuthorBook author = new AuthorBook();
		author.setName("shakessphere");
		AuthorBook authorBook = new AuthorBook();
		authorBook.setName("Valmiki");
		em.getTransaction().begin();
		em.persist(book);
		em.persist(book1);
		em.persist(author);
		em.persist(authorBook);
		em.getTransaction().commit();

		AuthorBook author1 = new AuthorBook();
		Book1 book4 = new Book1();
		book4.setTitle("abcd");
		book4.setPrice(890);
		book4.setAuthor(author1);
		Book1 book6 = new Book1();
		book6.setTitle("efgh");
		book6.setPrice(789);

		author1.setName("satya");
		author1.getList().add(book4);
		author1.getList().add(book6);
		AuthorBook author2 = new AuthorBook();
		Book1 b2 = new Book1();
		b2.setTitle("1234");
		b2.setPrice(650);
		b2.setAuthor(author2);
		Book1 b3 = new Book1();
		b3.setTitle("6578");
		b3.setPrice(560);

		author2.setName("satyadevi");
		author2.getList().add(b2);
		author2.getList().add(b3);
		em.getTransaction().begin();
		em.persist(author1);
		em.persist(author2);
		em.getTransaction().commit();

		/*
		 * Query query=em.createQuery("from Book1 where price>=500 and price<=1000");
		 * List<Book1> list=query.getResultList(); for (Book1 book2 : list) {
		 * System.out.println(book2); }
		 * 
		 * Query query1=em.createQuery("from Book1 where id=:bookId");
		 * query1.setParameter("bookId",id); List<Book1> list1=query1.getResultList();
		 * for (Book1 book2 : list1) { System.out.println(book2); }
		 * 
		 * 
		 * TypedQuery<Book1> query3 = em
		 * .createQuery("select list from AuthorBook author join author.list list where author.name=:nm"
		 * , Book1.class); query3.setParameter("nm", "satyadevi"); List<Book1> books =
		 * query3.getResultList(); for (Book1 book : books) { System.out.println(book);
		 * }
		 */
		System.out.println("Enter id1");
		int id1 = sc.nextInt();
		em.getTransaction().begin();
		TypedQuery<AuthorBook> q = em.createQuery("select book.author from Book1 book where book.id=:ID",
				AuthorBook.class);
		q.setParameter("ID", id1);

		List<AuthorBook> auth22= q.getResultList();
		for (AuthorBook authorBook1 : auth22) {
			System.out.println(authorBook1);
		}
		em.getTransaction().commit();

		// for (Book1 book1 : books) { System.out.println(book1); }

//List<AuthorBook> auth=query4.getResultList();
//for (AuthorBook authorBook : auth) {
		// System.out.println(authorBook);
//}
	}

}
