package com.cg.labbook;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Delete {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Author author= new Author(104, "Ved", "Kamesh", "yadav", 7898767);
		System.out.println("enter id");
		int authId=scanner.nextInt();
		em.getTransaction().begin();
		em.persist(author);
		Author auth=em.find(Author.class,authId);
		em.remove(auth);
		System.out.println("deleted");
		em.getTransaction().commit();

	}

}
