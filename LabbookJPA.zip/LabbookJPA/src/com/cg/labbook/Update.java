package com.cg.labbook;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Update {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		System.out.println("enter id");
		int authId=scanner.nextInt();
		em.getTransaction().begin();
		Author auth=em.find(Author.class,authId);
		
		auth.setFirstName("Veduru");
		auth.setPhoneNo(879765);
		em.getTransaction().commit();
		System.out.println("updated");
	}

}
