package com.cg.labbook;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Insert {

	public static void main(String[] args) {
		Author author= new Author(101, "V", "Satya", "Devi", 9505451);
		Author author1= new Author(102, "Teegala", "Prasanna", "Lakshmi", 5789765);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(author);
		em.persist(author1);
		em.getTransaction().commit();
		System.out.println("inserted");
		em.close();
		factory.close();
		

	}

}
