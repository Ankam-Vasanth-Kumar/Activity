package com.capgemini.customerdao;

import java.util.HashMap;
import java.util.Map;


import com.capgemini.ProductSupplier.Product;
import com.capgemini.ProductSupplier.Supplier;

public class SuperShoppeDAOImpl implements ISuperShoppeDAO {


	@Override
	public int addProduct(Product product) {
		Product p=productList.put(product.getProductId(), product);
		return product.getProductId();
	}
	@Override
	public Product getProduct(int productId) {
		return  productList.get(productId);
	}
	@Override
	public Map<Integer,Product>getAllProducts(){
		return productList;
	}
	@Override
	public int addSupplier(Supplier supplier) {
		Supplier s=supplierList.put(supplier.getSupplierId(), supplier);
		return supplier.getSupplierId();
	}
	@Override
	public Supplier getSupplier(int supplierId) {
		
		return supplierList.get(supplierId);
	}
	@Override
	public Map<Integer,Supplier>getAllSuppliers(){
		return supplierList;
	}

}
