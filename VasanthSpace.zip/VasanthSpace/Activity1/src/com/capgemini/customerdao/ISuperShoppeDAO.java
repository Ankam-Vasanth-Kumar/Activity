package com.capgemini.customerdao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.ProductSupplier.Product;
import com.capgemini.ProductSupplier.Supplier;

public interface ISuperShoppeDAO {
	Map<Integer, Product>productList=new HashMap<>();
	Map<Integer, Supplier>supplierList=new HashMap<>();
	int addProduct(Product product);

	Product getProduct(int productId);
	Supplier getSupplier(int supplierId);
public Map<Integer, Product> getAllProducts();

int addSupplier(Supplier supplier);

Map<Integer, Supplier> getAllSuppliers();

}
