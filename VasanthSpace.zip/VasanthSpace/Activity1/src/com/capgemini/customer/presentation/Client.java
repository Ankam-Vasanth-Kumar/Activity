package com.capgemini.customer.presentation;

import java.util.Map;
import java.util.Scanner;
import com.capgemini.customer.Exception.*;
import com.capgemini.customer.service.*;

import com.capgemini.ProductSupplier.*;
public class Client {
static	SuperShoppeServiceImpl service=new  SuperShoppeServiceImpl();
static Scanner scanner = new Scanner(System.in);

static void addProduct() throws ProductSupplierException {
	boolean flag=true;
	int productID=0;
	do {
		
	

	System.out.println("Enter product id ");

	   productID = scanner.nextInt();
	   flag=true;
              service.isProductIDValid(productID);
	
	
	}while(!flag);
	
	
	
	
	
	
	
	
	
	
	
	scanner.nextLine();
	
	System.out.println("Enter product name");
	String name = scanner.next();
	System.out.println("Enter product price");
	long price = scanner.nextLong();
	System.out.println("enter quantity");
	int quantity=scanner.nextInt();
	
	

	
}








static void addSupplier() {
	System.out.println("Enter supplier id ");
	int supplierID = scanner.nextInt();
	
	System.out.println("Enter supplier name");
	String name = scanner.next();
	System.out.println("Enter mobile no");
	scanner.nextLine();
	long mobile = scanner.nextLong();
	System.out.println("enter address");
	String address=scanner.next();
	if (!service.issupplierIDValid(supplierID)) {
		try {
			throw new ProductSupplierException("supplier id should be in numbers only");
		} catch (ProductSupplierException e) {
			System.err.println(e.getMessage());
		}
	} else {
 Supplier supplier= new Supplier(supplierID,name,mobile,address);
		int custId = service.addSupplier(supplier);
		System.out.println("Product Registered successfully and your id is:" + custId);
		System.out.println("Namaskar Application m apka swagat hai");
	}
}  






public static void main(String[] args) {

	/*
	 * CustomerServiceImpl service = new CustomerServiceImpl(); Scanner scanner =
	 * new Scanner(System.in);
	 */
	String option = null;
	do {
		System.out.println("1.Add Product\n2.Add Supplier\n3.display products\n4.display Supplier\n0.exitl");
		int choice = scanner.nextInt();
		switch (choice) {
		case 0:
			System.exit(0);
		case 1: {
			try {
				addProduct();
			} catch (ProductSupplierException e) {
				
				e.getMessage();
			}
		}
			break;
		case 2:{
			addSupplier();
		} break;
		case 3: {
			Map<Integer, Product>productList=service.getAllProducts();
			System.out.println(productList);
		}
			break;
		case 4:{
			Map<Integer, Supplier>supplierList=service.getAllSuppliers();
			System.out.println(supplierList);
			
		}break;

		default:
			System.out.println("Enter 1 to 5 only");
			break;
		}
		System.out.println("Press y to continue");
		option = scanner.next();
	} while (option.equalsIgnoreCase("y"));

	scanner.close();

}

}
