package com.capgemini.customer.service;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ProductSupplier.Product;
import com.capgemini.ProductSupplier.Supplier;
import com.capgemini.customer.Exception.ProductSupplierException;
import com.capgemini.customerdao.*;
public class SuperShoppeServiceImpl implements ISuperShoppeService {
	ISuperShoppeDAO supershoppedao=new SuperShoppeDAOImpl();

	public boolean isProductIDValid(int productID) {
		String pid=String.valueOf(productID);
		Pattern idPattern=Pattern.compile("^[0-9]{1,}$");
		Matcher match=idPattern.matcher(pid);
		if(match.matches()) {
			return true;
		}
		return false;
	}

	public boolean isproductNameValid(String name) throws ProductSupplierException {
		String pid=String.valueOf(name);
		Pattern idPattern=Pattern.compile("^[A-Z]{1,}$");
		Matcher match=idPattern.matcher(pid);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}

	public boolean isPriceValid(long price) {
		String mobile=String.valueOf(price);
		Pattern nameptn=Pattern.compile("^[0-9]{1,}$");
		Matcher match=nameptn.matcher(mobile);
		if(match.matches())
		{
		return true;	
		}
		return false;
	}

	public boolean isQuantityValid(int quantity) {
		String pquantity=String.valueOf(quantity);
		Pattern idPattern=Pattern.compile("^[0-9]{1,}$");
		Matcher match=idPattern.matcher(pquantity);
		if(match.matches()) {
			return true;
		}
		return false;
	}
@Override
	public int addProduct(Product product) {
		int productID= (int) (Math.random() * 1000);// gives huge numbers Method-1
		// Random random=new Random(1000); Gives less numbers Method-2 usually not
		// preferred
		product.setProductId(productID);
		return supershoppedao.addProduct(product);

	}


	
	@Override
	public Map<Integer, Product> getAllProducts() {
		return supershoppedao.getAllProducts();
		
	}

	@Override
	public int addSupplier(Supplier supplier) {
		
		int supplierID= (int) (Math.random() * 1000);// gives huge numbers Method-1
		// Random random=new Random(1000); Gives less numbers Method-2 usually not
		// preferred
		supplier.setSupplierId(supplierID);
		return supershoppedao.addSupplier(supplier);
	}

	public boolean issupplierIDValid(int supplierID) {
		String pid=String.valueOf(supplierID);
		Pattern idPattern=Pattern.compile("^[0-9]*$");
		Matcher match=idPattern.matcher(pid);
		if(match.matches()) {
			return true;
		}
		return false;
	}

	
	@Override
	public Map<Integer, Supplier> getAllSuppliers() {
		return supershoppedao.getAllSuppliers();
		
	}

	
	

}
