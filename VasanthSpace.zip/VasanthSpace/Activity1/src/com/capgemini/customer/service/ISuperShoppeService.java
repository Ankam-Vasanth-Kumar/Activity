package com.capgemini.customer.service;
import com.capgemini.ProductSupplier.*;
import com.capgemini.customer.Exception.ProductSupplierException;
import java.util.Map;



public interface ISuperShoppeService {
	public boolean isProductIDValid(int productID) throws ProductSupplierException;
	public boolean isproductNameValid(String name) throws ProductSupplierException;
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public Map<Integer, Product> getAllProducts();
	public Map<Integer,Supplier> getAllSuppliers();


}
