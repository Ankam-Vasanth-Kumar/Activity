package com.capgemini.ShoppingKart2.DAO;

import java.util.Map;

import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;

public class ItemDaoImpl implements ItemDao {

	@Override
	public Map<Integer, Item> getItems() {
		
		return null;
	}

	

	@Override
	public boolean addItems(Order item) {
		addedList.put(item.getOrderId(), item);
		return true;
	}

	

	

}
