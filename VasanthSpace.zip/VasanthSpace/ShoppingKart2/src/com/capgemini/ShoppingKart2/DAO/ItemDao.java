package com.capgemini.ShoppingKart2.DAO;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;

public interface ItemDao {

	public Map<Integer, Item>getItems();

	
	HashMap<Integer, Order>addedList=new HashMap<>();

	boolean addItems(Order item);
	
}
