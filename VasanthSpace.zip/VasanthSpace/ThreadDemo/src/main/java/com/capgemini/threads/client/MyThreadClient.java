package com.capgemini.threads.client;

import com.capgemini.threads.MyThread;

public class MyThreadClient {
public static void main(String[] args) {
	MyThread thread1=new MyThread("one");
	thread1.setName("first");
	MyThread thread2=new MyThread("two");
	thread2.setName("second");
	//thread1.setPriority(Thread.MAX_PRIORITY);
	//thread2.setPriority(Thread.MIN_PRIORITY);
	thread1.start();
	try {
		thread1.join();
	}catch(InterruptedException e) {
		e.printStackTrace();
	}
	thread2.start();
}
}
