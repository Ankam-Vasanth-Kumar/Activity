package com.capgemini.threads.client;

public class MainThread implements Runnable {
	public void run() {
		for(int i=0;i<10;i++)
		{
			if(Thread.currentThread().getName().equals("odd")&&(i%2!=0)) {
				System.out.println(Thread.currentThread().getName()+"==>"+i);
			}
			else if(Thread.currentThread().getName().equals("even")&&(i%2==0)) {
				
				System.out.println(Thread.currentThread().getName()+"==>"+i);
			}
		}
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		MainThread odd1=new MainThread();
		MainThread even1=new MainThread();
		Thread odd=new Thread(odd1);
		odd.setName("odd");
		Thread even=new Thread(even1);
		even.setName("even");
		odd.start();
		even.start();
	}
}
