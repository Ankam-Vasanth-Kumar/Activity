package com.capgemini;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConsumerSupplierDemo {

	public static void main(String[] args) {
		Consumer<String> consumer = (name) -> {
			System.out.println("consumer printing " + name);
		};
		consumer.accept("Sparrow");
		// supplier
		Supplier<String> supplier = () -> "\nhello from supplier\n";
		System.out.println(supplier.get());
		consumer.accept(supplier.get());
		List<Integer> mylist = Arrays.asList(30, 40, 50, 10, 454);
		System.out.println(mylist);
		Consumer<List<Integer>> printlistconsumer = (list) -> {
			for (Integer i : list) {
				System.out.println(i + " ");
			}
			System.out.println();
		};
		printlistconsumer.accept(mylist);

		Consumer<List<Integer>> printlistconsumersort = (list) -> {
			Collections.sort(list);
			for (Integer i : list) {
				System.out.println(i + " ");
			}
			System.out.println();
		};
		printlistconsumersort.accept(mylist);
		BiConsumer<String, Integer> biconsumer = (name, age) -> {
			System.out.println("name:" + name + "   age:" + age);
		};
		biconsumer.accept("amber", 50);

	}

}
