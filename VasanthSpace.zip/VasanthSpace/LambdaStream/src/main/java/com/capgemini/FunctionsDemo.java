package com.capgemini;

import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;

public class FunctionsDemo {

	public static void main(String[] args) {
	Function<Integer, Double>fun1=(n)->n/3.0;
	System.out.println("25/3.0=>"+fun1.apply(25));
    BiFunction<Integer, Integer, Double>bifun=(x,y)->x+y+0.0;
    System.out.println("10+20=>"+bifun.apply(10, 20));
    Scanner sc=new Scanner(System.in);
    BiFunction<Integer, Integer, Integer>bifun2=(x,y)->x>y?(x):(y);
    System.out.println("10?20=>"+bifun2.apply(10, 20));
    Predicate<Integer>oddcheck=(n)->n%2!=0;
    System.out.println("13 is odd?=>"+oddcheck.test(13));

	 Predicate<Integer>voter=(n)->n>18;
	 System.out.println("21 age eligible to vote?=>"+voter.test(21));
	 BiPredicate<Integer, Integer>min=(a,b)->a<b;
	 System.out.println("10,20 minimum:"+(min.test(10, 20)?10:20));
	 }
}
