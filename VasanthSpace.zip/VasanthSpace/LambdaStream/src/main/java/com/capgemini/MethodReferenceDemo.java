package com.capgemini;

import java.util.function.Consumer;
import java.util.function.Supplier;

class Product{
	String name="computer";
	int price=30000;
	
}
interface Say{
	void sayMsg();
	
}
public class MethodReferenceDemo {
static void sayHi() {
	System.out.println("welcome from static method\n");
}
void bye() {
	System.out.println("Thank you\n");
}
	public static void main(String[] args) {
		Product p=new Product();
		System.out.println("Nmae:"+p.name);
		System.out.println("price:"+p.price);
		Supplier<Product>p1=Product::new;
		System.out.println("Name:"+p1.get().name);
		System.out.println("price:"+p1.get().price);
		Say say=MethodReferenceDemo::sayHi;
		say.sayMsg();
		Consumer<String>consumer=(s)->System.out.println(s);
		consumer.accept("consumer says hi");
		
		

	}

}
