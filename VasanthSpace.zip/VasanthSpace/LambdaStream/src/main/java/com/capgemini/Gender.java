package com.capgemini;

public enum Gender {
MALE,FEMALE;
}
