package com.capgemini;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BasicStream {

	public static void main(String[] args) {
		List<Integer>list=Arrays.asList(10,5,6);
		System.out.println(list);
		System.out.println("collect");
		int sum=list.stream().collect(Collectors.summingInt(i->i));
		System.out.println("sum"+sum);
		//concat
		List<Integer>list1=Arrays.asList(10,5,23);
		List<Integer>list2=Arrays.asList(11,4,22);
		Stream<Integer>concatvalue=Stream.concat(list1.stream(),list2.stream());
		System.out.println("concat values");
	concatvalue.forEach(System.out::println);
	System.out.println("count");

	System.out.println("list2 count:,"+list2.stream().count());
	List<Integer>list3=Arrays.asList(6,34,2,1,0,66);
	System.out.println("sorted data");
	list3.stream().sorted().forEach(System.out::println);
	System.out.println("count of event numbers");
	System.out.println(list3.stream().filter(n->n%2==0).count());
	Predicate<Integer>p=n->n%2==0;
	System.out.println("all Match:"+list3.stream().allMatch(p));
	System.out.println("all Match:"+list3.stream().anyMatch(p));
	System.out.println("all Match:"+list3.stream().noneMatch(p));
	List<String>cities=Arrays.asList("Hyderabad","Bangalore","Delhi","Mumbai");
	cities.stream().forEach(System.out::println);
	System.out.println("print the cities nameLength>5");
	List<String>resultlist=cities.stream().filter((name->name.length()>5)).collect(Collectors.toList());
	resultlist.stream().forEach(System.out::println);
	System.out.println("each city name lrngth");
	cities.stream().map(s->s.length()).forEach(System.out::println);
	Optional<Integer>sumvalue=list.stream().reduce((a,b)->a+b);
	System.out.println(sumvalue);
	
	}

}
