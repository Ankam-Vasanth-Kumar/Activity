package com.capgemini.jdbc;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RetrieveData {
static Connection connection=null;
static Statement statement=null;
static ResultSet resultSet=null;
public static void main(String[] args) {
	
	connection=DBConnection.getConnection();
	statement=(Statement) connection.createStatement();
	resultSet=statement.executeQuery();
	
}
}
