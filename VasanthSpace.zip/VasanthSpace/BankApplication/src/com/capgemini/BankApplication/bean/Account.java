package com.capgemini.BankApplication.bean;

public class Account {
int accountNo;
double balance;
}
