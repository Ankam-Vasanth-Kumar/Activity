package com.capgemini.BankApplication.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.BankApplication.bean.Customer;
import com.capgemini.BankApplication.bean.Transaction;

public class UtilityClass {
public static Map<Integer, Customer>customerList=new HashMap<>();
public static Map<Integer, Transaction>TransactionList=new HashMap<>();
static {
	customerList.put(1000, new Customer(1000,"Jack","jack@gmail.com", "9848022338","3-2-3 ATP"));
	customerList.put(1001, new Customer(1001,"Saprrow","sparrow@gmail.com", "9848022337","3-2-3 DTP"));
	customerList.put(1002, new Customer(1002,"Bill","Bill@gmail.com", "9848022336","3-2-3 STP"));
	customerList.put(1003, new Customer(1003,"Gates","Gates@gmail.com", "98480223385","3-2-3 EPIP"));
	customerList.put(1004, new Customer(1004,"sundar","sundar@gmail.com", "9848022334","3-2-3 Brooke field"));
	customerList.put(1005, new Customer(1005,"pichhai","pichhai@gmail.com", "9848022333","3-2-3 WhiteField"));
	TransactionList.put(2000, new Transaction(2000,"Debit","1-1-2019", 1000,100200,5000000));
	TransactionList.put(2000, new Transaction(2001,"credit","1-2-2019", 1001,100201,6000000));


}
	
	
	
}
