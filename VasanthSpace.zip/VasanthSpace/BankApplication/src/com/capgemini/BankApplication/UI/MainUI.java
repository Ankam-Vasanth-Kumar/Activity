package com.capgemini.BankApplication.UI;

import java.util.Scanner;

public class MainUI {

	public static void main(String[] args) {
	boolean flag=true;
	do {
		System.out.println("1.check Balance\n2.Deposit\n3.Withdraw\n4.exit");
		Scanner scanner=new Scanner(System.in);
		int ch=scanner.nextInt();
		switch(ch) {
		case 1:
		}
	}while(flag);
		
		

	}

}
