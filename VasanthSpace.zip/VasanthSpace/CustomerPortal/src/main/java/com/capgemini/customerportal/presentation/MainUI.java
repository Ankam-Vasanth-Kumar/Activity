package com.capgemini.customerportal.presentation;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.customerportal.Customer;
import com.capgemini.customerportal.exception.CustomerPortalException;
import com.capgemini.customerportal.service.CustomerService;
import com.capgemini.customerportal.service.CustomerServiceImpl;
/**
 * 
 * @author vaankam
 *@version 1.0
 *
 *
 *
 */
public class MainUI {
	public static void main(String[] args)
	
	{   /**customerservice object initialized
	*
	*
	*/
		CustomerServiceImpl service=new CustomerServiceImpl();
		
		Scanner scanner=new Scanner(System.in);
		String option=null;
		do {
			System.out.println("1.Add\n2.update\n3.delete\n4.viewid\n5.viewAll\n 6.exit\n");
			int ch=scanner.nextInt();
			switch(ch) {
			case 6:System.exit(0);
			case 1:{
				System.out.println("enter name");
				
				
				try {
					String name=scanner.next();
				             if(!service.isNameValid(name)) {
				             try {
					              throw new CustomerPortalException(" name is Invalid");
				                  }catch(CustomerPortalException e) {
				                 	System.err.println(e.getMessage());
				                                              }
				             }
				}
				catch(InputMismatchException e) {
					System.err.println(e.getMessage());
				}
				
				
				System.out.println("enter address");
				String address=scanner.next();
				System.out.println("enter phone");
				long phone=scanner.nextLong();
				if(!service.isPhoneValid(phone))
					try {
						throw new CustomerPortalException(" Invalid phone number");
					}catch(CustomerPortalException e) {
						System.err.println(e.getMessage());
					}	
				
				Customer customer=new Customer(0,name,address,phone);
				int custId=service.add(customer);
				System.out.println("customer registerd successfully and id is:+custId");
			}
			break;
			case 2:
			{
				System.out.println("enter custid to update");
				int custId=scanner.nextInt();
				System.out.println("enter name");
				String name=scanner.next();
				System.out.println("enter address");
				String address=scanner.next();
				System.out.println("enter phone");
				long phone=scanner.nextLong();
				Customer customer=new Customer(custId,name,address,phone);
				try
				{
					boolean status=service.update(customer);
					if(status)
					{
						System.out.println("updated succesfully");
					}
				}catch(CustomerPortalException e)
				{
					System.out.println(e.getMessage());
				}
			}
			break;
			case 3:{
				System.out.println("enter custid to delete");
				int custId=scanner.nextInt();
				try {
					boolean status=service.delete(custId);
					if(status)
					{
						System.out.println(custId+"deleted successfully");
					}
				}catch(CustomerPortalException e)
				{ 
					System.out.println(e.getMessage());
				}
			}break;
			case 4:
			{
				System.out.println("enter custid to view");
				int custId=scanner.nextInt();
				Customer c=service.getCustomer(custId);
				System.out.println(c);
			}
	
			case 5:{
				List<Customer>customerList=service.getCustomer();
				System.out.println(customerList);
			}
			}
			System.out.println("press y to continue:\n");
			option=scanner.next();
		}while(option.equalsIgnoreCase("y"));
		scanner.close();
	}

}
