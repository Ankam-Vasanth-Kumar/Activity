package com.capgemini.customerportal.dao;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.customerportal.Customer;

public class CustomerDaoImpl implements CustomerDAO {
	boolean status=false;
Logger log=Logger.getLogger("CustomerDaoImpl");

	@Override
	public int addCustomer(Customer customer) {
		log.info("CustomerDao addcustomer()started");
customerList.put(customer.getCustomerID(), customer);
		log.info("addCustomer();finshed and returning");
		return customer.getCustomerID();
		
	}

	@Override
	public boolean updateCustomer(Customer customer) {
Customer c=customerList.put(customer.getCustomerID(), customer);
if(c!=null)
	status=true;
return status;
		
		
	}

	@Override
	public boolean deleteCustomer(int customerID) {
		Customer customer=customerList.remove(customerID);
      if(customer!=null)
	status=true;
		return status;
	}

	@Override
	public Customer getConsumer(int customerID)
	{
		return customerList.get(customerID);
	}
	@Override
	public Customer getCustomer(int customerID) {
		
		return customerList.get(customerID);
	}

	@Override
	public Map<Integer,Customer> getCustomer() {
		
		return customerList;
	}

	

}
