package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.bean.FlatOwner;
import com.cg.bean.RegistrationDetails;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDao {
static Map<Integer,FlatOwner>owners=new HashMap<>();
static {
owners.put(1,new FlatOwner(1,"vaishali",8885401174L));
owners.put(1,new FlatOwner(1,"Megha",8885401175L));
owners.put(1,new FlatOwner(1,"Manish",8885401176L));
}
Map<Integer,RegistrationDetails>flatDetails=new HashMap();
@Override
public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
	// TODO Auto-generated method stub
	return null;
}
@Override
public ArrayList<Integer> getAllOwnerIds() {

	return owners;
}

}
