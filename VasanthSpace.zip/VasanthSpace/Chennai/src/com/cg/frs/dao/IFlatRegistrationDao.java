package com.cg.frs.dao;

import java.util.ArrayList;

import com.cg.frs.service.FlatRegistrationDTO;

public interface IFlatRegistrationDao {
	
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO  flat);
	ArrayList<Integer>getAllOwnerIds();
}
