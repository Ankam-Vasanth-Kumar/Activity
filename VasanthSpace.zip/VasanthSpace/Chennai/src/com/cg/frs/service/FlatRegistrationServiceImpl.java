package com.cg.frs.service;

import java.util.ArrayList;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		
		return null;
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
	
		return null;
	}

}
