package com.cg.frs.service;

public interface IFlatRegistrationService {
FlatRegistrationDTO registerFlat(FlatRegistrationDTO  flat);

}
