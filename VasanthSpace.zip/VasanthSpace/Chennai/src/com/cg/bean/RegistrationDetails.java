package com.cg.bean;

public class RegistrationDetails {
  int id;
  int type;
  int flatArea;
  int amount;
public RegistrationDetails() {
	super();
}
public RegistrationDetails(int id, int type, int flatArea, int amount) {
	super();
	this.id = id;
	this.type = type;
	this.flatArea = flatArea;
	this.amount = amount;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getType() {
	return type;
}
public void setType(int type) {
	this.type = type;
}
public int getFlatArea() {
	return flatArea;
}
public void setFlatArea(int flatArea) {
	this.flatArea = flatArea;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return "RegistrationDetails [id=" + id + ", type=" + type + ", flatArea=" + flatArea + ", amount=" + amount + "]";
}
  
	
	
}
