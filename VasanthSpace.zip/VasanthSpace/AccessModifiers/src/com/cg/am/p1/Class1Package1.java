package com.cg.am.p1;

public class Class1Package1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
