package com.cg.labwork;

import java.util.Scanner;

class Sortarray {
	public int getSecondSmallest(int arr[]) {
		int temp;
		for(int i=0;i<arr.length;i++) 
		{
			for(int j=0;j<arr.length;j++) 
			{
				if(arr[i]<arr[j])
				{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		return arr[1];
	}

	public static void main(String[] args) {
		int size;
		Sortarray obj = new Sortarray();
		System.out.println("enter size");
		Scanner scanner = new Scanner(System.in);
		size = scanner.nextInt();
		int num[]=new int[size];
		for(int i=0;i<size;i++)
			num[i]=scanner.nextInt();
		int secondlast = obj.getSecondSmallest(num);
		System.out.println("2nd smallest number:"+secondlast);

	}

}
