package com.cg.labwork;

import java.util.Scanner;

public class evenNumbers {
	public int  evenCheck(int num) {
		int count=0;
		int n=num%10;
		int remainingNumber=num;

		while(remainingNumber>0)
		{
			if(n%2==0){
				count++;
				
				remainingNumber=remainingNumber/10;
				n=remainingNumber%10;
				}
			else {
		
				n=remainingNumber%10;
				remainingNumber=remainingNumber/10;
				
			}
		}
		
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		evenNumbers obj = new evenNumbers();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		
		System.out.println("no of even digits are:" + obj.evenCheck(n));


	}

}
