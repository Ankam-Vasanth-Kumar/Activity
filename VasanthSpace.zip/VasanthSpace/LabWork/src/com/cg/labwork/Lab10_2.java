package com.cg.labwork;

public class Lab10_2 implements Runnable{

	public static void main(String[] args) {
		Lab10_2 obj=new Lab10_2();
		Thread t=new Thread(obj);
		System.out.println("started");
		t.start();

	}


	public void run() {
		System.out.println("in run started");
		for(int i=1;i<=10;i++)
		{
			System.out.println("timer:"+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			if(i!=10)
			continue;
			else {
			System.out.println("timer refreshed");
			i=0;continue;
			}
			
		}
		
	}

}
