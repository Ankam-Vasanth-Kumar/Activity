package com.cg.labwork;

import java.util.Scanner;

public class lab5_3 {
	public int printPrime(int n)
	{
		 int i =0;
	       int num =0;
	       //Empty String
	       String  primeNumbers = "";

	       for (i = 1; i <= n; i++)         
	       { 		  	  
	          int counter=0; 	  
	          for(num =i; num>=1; num--)
		  {
	             if(i%num==0)
		     {
	 		counter = counter + 1;
		     }
		  }
		  if (counter ==2)
		  {
		     //Appended the Prime number to the String
		     primeNumbers = primeNumbers + i + " ";
		  }	
	       }	
	       System.out.println("Prime numbers  are :");
	       System.out.println(primeNumbers);
		return 1;
	}

	public static void main(String[] args) {
		lab5_3  obj=new lab5_3();
		
		System.out.println("enter n");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();
		obj.printPrime(num);		

	}

}
