package com.cg.labwork;

import java.util.Scanner;

public class SubSequentNumbers {
public int generateSubSequent(int n) {
	int number=0,k=n;
	int last=0;
	int remainingNumber=n;
    int remainder=remainingNumber%10;
	while(remainingNumber>0)
	{
		if(n>0)
		{
			
			n=remainingNumber%10;
			remainingNumber=remainingNumber/10;
			number=number*10+n;
		}
	
    }
	
	int remaining=number;
    int remain=remaining%10;
	while(remaining>0)
	{
		if(number>0)
		{
			
			number=remaining%10;
			remaining=remaining/10;
			if(number==9)
				number=-1;
			last=last*10+(++number);
		}
	
    }
	
	
	
	
	System.out.println("last:"+last);
	return last;
}
	public static void main(String[] args) {
		SubSequentNumbers obj = new SubSequentNumbers();
		System.out.println("enter a number");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int result = obj.generateSubSequent(n);
		System.out.println("subsequent number:"+ result);
	}

}
