package com.cg.labwork;

import java.util.HashMap;
import java.util.Scanner;

public class Lab9_2 {
	public HashMap<Character, Integer>	countCharacters(char[] array2)
	{    int flag=1;
	HashMap<Character, Integer>hm=new HashMap<Character, Integer>();
		int length=array2.length;
		   for(int i=0;i<array2.length;i++)
		   {
						for(int j=i-1;j>=0;j--)
						{
							
						if(array2[i]==array2[j])
						{
							flag=0;
		                     break;				
						}
						else
							flag=1;
						}
						if(flag==1)
						{ 
							int count=0;
							for(int k=i;k<array2.length;k++)
							{
								if(array2[i]==array2[k])
									count++;
								
									
							}
							System.out.println(array2[i]+":"+count);
							hm.put(array2[i], count);
							
						}
						else
						{
							
						}
		   }
		return hm;
		   
		   
	   
	}


	public static void main(String[] args) {
		Lab9_2 obj=new Lab9_2();
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter name");
		String word=scanner.nextLine();
		char[] array=word.toCharArray();
		
		HashMap<Character, Integer>hs=new HashMap<Character,Integer>();
		hs=obj.countCharacters(array);
		System.out.println("hashmap:\n"+hs);
	}

}
