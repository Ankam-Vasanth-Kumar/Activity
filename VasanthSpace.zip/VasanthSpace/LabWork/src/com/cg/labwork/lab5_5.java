package com.cg.labwork;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class lab5_5 {
	static Pattern nameptn=Pattern.compile("^[0-9]*$");
	
	static boolean validateName(String name)
	{
		Matcher match=nameptn.matcher(name);
		if(match.matches())
		{
	      return true;
		}
		return false;
	}
	
		

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		lab5_4 obj=new lab5_4();
		try {
		
		System.out.println("enter last age");
		String age=scanner.next();
		if(validateName(age))
		{
			System.out.println("age is in numbers only");
	int agea=Integer.parseInt(age);
		if(agea<15)
			throw new NotValidAge();
		}
		else
		{
			System.out.println("enter numbers only");
		}
	}
		catch(NotValidAge e)
		{
			System.out.println("age should be >15");
		}

	}

}
class NotValidAge extends Exception {
	public NotValidAge() {
		
	}

}
