package com.cg.labwork;

import java.util.Scanner;

public class count {
	public int calculate3(int num) {
		int count=0;
		int n=num%10;
		int remainingNumber=num;

		while(remainingNumber>0)
		{
			if(n%3==0){
				count++;
				
				remainingNumber=remainingNumber/10;
				n=remainingNumber%10;
				}
			else {
		
				n=remainingNumber%10;
				remainingNumber=remainingNumber/10;
				
			}
		}
		return count;
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		count obj = new count();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		
		System.out.println("no of digits divisible by 3 are:" + obj.calculate3(n));

	}

}
