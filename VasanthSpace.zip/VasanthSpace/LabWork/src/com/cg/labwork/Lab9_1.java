package com.cg.labwork;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Lab9_1 {
	HashMap<Integer,Integer>hm=new HashMap<Integer,Integer>();
	public List<Integer> getValues(HashMap<Integer, Integer> hm) {
		
		 List<Integer>ls=new ArrayList<Integer>(hm.values());
		
		return ls; 
	}

	public static void main(String[] args) {
		Lab9_1 obj=new Lab9_1();
		HashMap<Integer,Integer>hmain=new HashMap<Integer,Integer>();
		
	hmain.put(1, 11);
	hmain.put(3, 33);
	hmain.put(0, 02);
	hmain.put(5, 55);
	hmain.put(4, 44);
	hmain.put(6, 66);
	List<Integer>lsmain=new ArrayList<Integer>();
	System.out.println("main hashmap"+hmain);
   lsmain= obj.getValues(hmain);
   System.out.println("GOT the values from hashmap in sorted order:\n"+lsmain);
	}

}
