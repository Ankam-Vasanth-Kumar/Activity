package com.cg.labwork;

import java.util.Scanner;

public class lab5_2 {
	public int nonRecursive(int first,int second,int n)
	{
		int temp,i=1;
		System.out.println(first);
		System.out.println(second);
		while(i<=n-2)
		{
			temp=first+second;
			System.out.println(temp);
			first=second;
			second=temp;
			i++;
		}
		return 0;
		
	}
	public int recursive(int first,int second,int n)
	{int temp=first+second;
	
	
	if(n>=0)
	{
		n--;
		System.out.println(" "+temp);
		return(recursive(second,temp,n));
	}
	else
	{
		
	}
	
	return 1;	
	}
	
	public static void main(String[] args) {
		
		int i=1,j=1;
		lab5_2 obj=new lab5_2();
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter nth value");
		int nth = scanner.nextInt();
		System.out.println("non recursive"+obj.nonRecursive(i, j,nth));
		System.out.println(i+" ");
		System.out.println(j+" ");
		System.out.println("non recursive"+obj.recursive(i, j,nth-2));
		
		
		}

}
