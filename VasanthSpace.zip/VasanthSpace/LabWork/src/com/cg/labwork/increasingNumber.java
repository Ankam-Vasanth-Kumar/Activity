package com.cg.labwork;

import java.util.Scanner;

public class increasingNumber {
	
	public boolean checkNumber(int number) {
		int remainingNumber=number;
		int n=number%10;
		
		remainingNumber=remainingNumber/10;
		
		
		int flag=1;
		
		while(remainingNumber>0)
		{
			if((n >remainingNumber%10)&& flag==1) {
				
				n=remainingNumber%10;
				remainingNumber=remainingNumber/10;
				}
			else {
				flag=0;
				
				n=remainingNumber%10;
				remainingNumber=remainingNumber/10;
				
			}
		}
		if(flag==1)
			return true;
		else
			return false;
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		increasingNumber obj = new increasingNumber();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int number = scanner.nextInt();
		boolean check = obj.checkNumber(number);
		if(check)
			System.out.println("the given number is increasing number");
		else
			System.out.println("not a increasing number");
	}

}
