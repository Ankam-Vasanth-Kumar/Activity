package com.cg.labwork;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab8_6 {

	public static void main(String[] args) {
		int day,month,year;
		System.out.println("enter day");
		Scanner scanner=new Scanner(System.in);
		day=scanner.nextInt();
		System.out.println("enter month");
		
	month=scanner.nextInt();
		System.out.println("enter year");
		
		year=scanner.nextInt();
		 
		 LocalDate ID = LocalDate.of( year,month,day );
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDate now = LocalDate.now();  
	

		   Period diff=Period.between(ID, now);
	System.out.println("difference between"+ID+"&"+now +" :" +diff.getYears()+" "+diff.getMonths()+" "+diff.getDays());

}
}
