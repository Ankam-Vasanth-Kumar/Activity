package com.cg.labwork;

import java.util.Scanner;

public class differenceOfSquare {
	public int calculateDifference(int n) {
	int squaresSum=0,totalSum=0,sum;
	for(int i=1;i<=n;i++)
	{
		squaresSum=squaresSum+i*i;
	}
	for(int j=1;j<=n;j++)
	{
		totalSum=totalSum+j;
	}
	sum=squaresSum-(totalSum*totalSum);
		
	return sum;
	}
	
	public static void main(String[] args) {
		differenceOfSquare obj = new differenceOfSquare();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int number = scanner.nextInt();
		System.out.println("sum:" + obj.calculateDifference(number));
		
 	}

}
