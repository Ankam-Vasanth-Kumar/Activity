package com.cg.labwork;

import java.util.Scanner;

public class powerOf2 {
	public boolean checkNumber(int n) {
		int j=2;
		while(j<n) {
			j=j*2;
		}
		if(j==n)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		powerOf2 obj = new powerOf2();
		System.out.println("enter n:");
		Scanner scanner = new Scanner(System.in);
		int number = scanner.nextInt();
		boolean check=obj.checkNumber(number);
		if(check)
			System.out.println("the given number is power of 2");
		else
			System.out.println("not a power of 2");
			
		
		

	}

}
