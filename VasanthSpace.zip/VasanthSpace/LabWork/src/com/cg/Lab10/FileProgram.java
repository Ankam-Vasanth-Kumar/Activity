package com.cg.Lab10;

public class FileProgram {

	public static void main(String[] args) {
	CopyDataThread obj=new CopyDataThread();
	Thread t=new Thread( obj);
	t.start();
	
	}

}
