package com.cg.IODemo;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOError;
import java.io.IOException;

public class dataIO {
	int[] eid= {11,22,33};
	String name[]= {"amber","kiran","harshit"};
	double salary[]= {25000,25000,25003};
	
	void mywrite() throws IOException
	{
		DataOutputStream dataio= new DataOutputStream(
				new BufferedOutputStream(new FileOutputStream("data.txt")));
		for(int i=0;i<3;i++)
		{
			dataio.writeInt(eid[i]);
			dataio.writeUTF(name[i]);
			dataio.writeDouble(salary[i]);
			
		}
		dataio.close();
		
	}
	void myread() throws IOException
	{
		DataInputStream datainput=new DataInputStream(
				new BufferedInputStream(new FileInputStream("data.txt")));
		for(int i=0;i<3;i++)
		{
			System.out.println(datainput.readInt()+" "+datainput.readUTF()+" "+datainput.readDouble());
			
		}
		datainput.close();
	}
	

	public static void main(String[] args) {
		dataIO io=new dataIO();
		try
		{
			io.mywrite();
			io.myread();
		}
		catch(Exception e )
		{
			e.printStackTrace();
		}
		
		
	}

}
