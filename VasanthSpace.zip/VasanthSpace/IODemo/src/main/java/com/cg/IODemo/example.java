package com.cg.IODemo;


public class example {
	int a;

}
