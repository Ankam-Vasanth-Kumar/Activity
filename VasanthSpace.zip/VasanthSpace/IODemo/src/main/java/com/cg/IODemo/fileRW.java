package com.cg.IODemo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class fileRW {
public static void main(String[] args) {
		FileInputStream fin=null;
		FileOutputStream fout=null;
		try
		{
			fin = new FileInputStream("src/main/java/com/cg/IODemo/FileDemo.java");	
			fout = new FileOutputStream("src/main/java/my.doc");
			int i=0,line=1;
			System.out.print(line+" ");
			while(i!=-1) 
			{  
				
				i=fin.read();
				
				fout.write(i);
				
				System.out.print((char)i);
				if(i=='\n') {
					line++;
					System.out.print(line+" ");
				}
			}
			
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
