package com.cg.IODemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class countWordsLines {

	public static void main(String[] args) {
		int words=0,lines=0,chaaar=0;
		FileInputStream fin=null;
		FileOutputStream fout=null;
		try
		{
			fin = new FileInputStream("src/main/java/com/cg/IODemo/example.java");	
			fout = new FileOutputStream("src/main/java/my.doc");
			int i=0;
			while(i!=-1) 
			{
				i=fin.read();
				if(i==' ')
					words++;
				if(i=='\n')
					lines++;
				chaaar++;
				fout.write(i);
				
				
			}
			System.out.println("no of chaar"+chaaar);
			System.out.println("no of lines"+lines);
			System.out.println("no of words"+words);
			
			
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
