package com.cg.IODemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ConsoleID {

	public static void main(String[] args) throws IOException {
		PrintWriter pw=new PrintWriter(System.out,true);
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		try
		{
			pw.println("enter a value");
			int a=Integer.parseInt(br.readLine());
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace();
		}
	}

}
