package com.cg.eis.service;

public interface EmployeeService {

	boolean isNameValid(String name);

	boolean isEmployeeIDValid(int empid);

	boolean isDesignationValid(String designation);

}
