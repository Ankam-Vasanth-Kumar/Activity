package com.cg.eis.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public boolean isNameValid(String name) {
		String name1=String.valueOf(name);
		Pattern patternname=Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
	}

	@Override
	public boolean isEmployeeIDValid(int empid) {
		String emp=String.valueOf(empid);
		Pattern pattern=Pattern.compile("^[0-9]{4,}$");
		Matcher match=pattern.matcher(emp);
		if(match.matches()) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isDesignationValid(String designation) {
		String name1=String.valueOf(designation);
		Pattern patternname=Pattern.compile("^[a-z]{5,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
	}

}
