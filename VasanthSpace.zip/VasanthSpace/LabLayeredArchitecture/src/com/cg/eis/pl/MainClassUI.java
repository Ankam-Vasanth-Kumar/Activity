package com.cg.eis.pl;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class MainClassUI {
	int Empid;
	String name;
	long salary;
	String Designation;
	Scanner scanner=null;
	EmployeeService service= new EmployeeServiceImpl();
	HashMap<Integer, Employee>hmap=new HashMap<>();

	public static void main(String[] args) {
		MainClassUI obj=new MainClassUI();
		Scanner sc=null;
		int option;
		String ch;
		do {
			System.out.println("1.Register Employee\nfind Insurance Scheme\n3.Dispaly Employee Details");
			sc=new Scanner(System.in);
			option=sc.nextInt();
			
			switch(option) {
			case 1:
				obj.register();
			
			}
			System.out.println("enter y to continue");
			sc=new Scanner(System.in);
			ch=sc.nextLine();
		}while(ch.equalsIgnoreCase("y"));
	}

	private void register() {
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Name");
			name=scanner.nextLine();
			try {
				flag=service.isNameValid(name);
				
				if(flag)
					throw new EmployeeException();
			}catch(EmployeeException e) {
				System.err.println("first letter in the name should be capital throws");
			}
			
		}while(flag);

		
	
	
	
	do {
		scanner=new Scanner(System.in);
		System.out.println("enter Employee ID");
		Empid=scanner.nextInt();
		try {
			flag=service.isEmployeeIDValid(Empid);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("Invalid Emp ID");
		}
		
	}while(flag);
	
	do {
		scanner=new Scanner(System.in);
		System.out.println("enter salary of the employee");
		salary=scanner.nextInt();
		try {
			flag=service.isEmployeeIDValid(salary);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("Enter Digits only");
		}
		
	}while(flag);

	do {
		scanner=new Scanner(System.in);
		System.out.println("enter Designation");
		Designation=scanner.nextLine();
		try {
			flag=service.isDesignationValid(Designation);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("enter designation properly");
		}
		
	}while(flag);
	String var="System Associate";

	if((salary>5000&&salary<20000)&&var.equals(Designation)) 
		
	
	
	
	
}
	
	
	
	
}