package com.cg;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		//HashSet<String> hs=new HashSet<>();
		LinkedHashSet<String> hs=new LinkedHashSet<>();
		//TreeSet<String>hs=new TreeSet<>();
		hs.add("java");
		hs.add("spring");
		hs.add("machine learning");
		hs.add("angular");
		hs.add("spring");
		System.out.println("hashset:"+hs);

	}

}
