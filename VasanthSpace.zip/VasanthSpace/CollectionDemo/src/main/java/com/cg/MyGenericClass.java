package com.cg;

public class MyGenericClass<T> {
	private void display(T a,T b) {
System.out.println("A="+a);
System.out.println("B="+b);
	}
	public static void main(String[] args)
	{
		MyGenericClass<Integer> mgc=new MyGenericClass<Integer>();
		mgc.display(10,20);
	}
	

}
