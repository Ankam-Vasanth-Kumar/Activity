package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		HashMap<Integer, String>map=new HashMap();
		map.put(7,"java");
		map.put(6,"cpp");
		map.put(5,"python");
		map.put(4,"php");
		map.put(2,"dbms");
		map.put(1,"c");
		System.out.println(map.size());
		System.out.println(map);
		System.out.println(map.remove(2));
		System.out.println("after remove");
		System.out.println(map);
		Set<Integer>set=map.keySet();
		for(Integer k:set) {
			System.out.println(map.get(k));
		}
        Collection<String>collection=map.values();
        List<String>list=new ArrayList<String>();
        list.addAll(collection);
        System.out.println("list values");
        System.out.println(list);
        }

}
