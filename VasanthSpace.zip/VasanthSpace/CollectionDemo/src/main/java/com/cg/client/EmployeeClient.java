package com.cg.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

import com.cg.beans.Employee;
import com.cg.service.NameSort;
import com.cg.service.SalarySort;

public class EmployeeClient {

	public static void main(String[] args) {
		//ArrayList<Employee>emplist=new ArrayList<>();
		//HashSet<Employee>emplist=new HashSet<>();
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter 1.empid-sort 2.name-sort  3.salarysort");
		int option=scanner.nextInt();
		TreeSet<Employee>emplist=null;
		if(option==1)
		{
			emplist=new TreeSet<>();
		}
		else if(option==2){
			emplist=new TreeSet<>(new NameSort());
		}
		else if(option==3)
		{
			emplist=new TreeSet<>(new SalarySort());
		}
		else {
			//System.out.println("Bhk DK Bose");
			System.exit(0);
		}
		Employee e1=new Employee(121,"amber",100,"analyst");
		Employee e2=new Employee(120,"varaha",200,"traine");
		Employee e3=new Employee(125,"vasanth",500,"analyst");
		Employee e4=new Employee(126,"kiran",800,"analyst");
		Employee e5=new Employee(123,"amber",400,"analyst");
		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		emplist.add(e4);
		emplist.add(e5);
		System.out.println(emplist);
		

	}

	

}
