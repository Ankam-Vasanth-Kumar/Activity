package com.cg.beans;

public class Employee implements Comparable<Employee> {
   private int empid;
   private String name;
   private double salary;
   private String designation;
   
   
	public Employee()  {
	super();
}


	public Employee(int empid, String name, double salary, String designation) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public String getDesignation() {
		return designation;
	}
	
	public void setDesignation(String designation) {
		this.designation = designation;
	}


	@Override
	public String toString() {
		return "\nEmployee [empid=" + empid + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ "]";
	}


	@Override
	public boolean equals(Object obj) {
		Employee e=(Employee)obj;
		
		return e.empid==this.empid;
	}


	@Override
	public int hashCode() {
		
		return this.empid;
	}


	public static void main(String[] args) {


	}


	@Override
	public int compareTo(Employee e) {
		if(this.empid>e.empid)
			return 1;
		else if(this.empid<e.empid)
		return -1;
		else
		return 0;
	}

}
