package com.capgemini.ShoppingKart2.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ShoppingKart2.DAO.ItemDao;
import com.capgemini.ShoppingKart2.DAO.ItemDaoImpl;
import com.capgemini.ShoppingKart2.Exception.ShoppingExceptions;
import com.capgemini.ShoppingKart2.bean.Item;
import com.capgemini.ShoppingKart2.bean.Order;

public class CustomerOrderServiceImpl implements CustomerOrderService {

	ItemDao itemdaoobj=new ItemDaoImpl();
	@Override
	public boolean addToCart(Order item) {
		int pid=(int)(Math.random()*1000);
		item.setItemId(pid);
		return itemdaoobj.addItems(item);
	}

	@Override
	public List<Order> printOrderedItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Item> getItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isNameValid(String name) throws ShoppingExceptions {
		String name1=String.valueOf(name);
		Pattern patternname=Pattern.compile("^[A-Z]{1}[a-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
}

	@Override
	public boolean isPhoneNoValid(String phone) throws ShoppingExceptions {
		 Pattern patternphone=Pattern.compile("^[6-9]{1}[0-9]{9}$")	;
		 Matcher match=patternphone.matcher(phone);
		 if(match.matches()) {
			 return false;
		 }
			return true;
	}

	
}
