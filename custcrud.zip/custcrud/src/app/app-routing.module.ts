import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerlistComponent } from './components/customerlist/customerlist.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { AddcustomerComponent } from './components/addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './components/updatecustomer/updatecustomer.component';
import { AddreactiveComponent } from './components/addreactive/addreactive.component';
import { LoginComponent } from './components/login/login.component';
import {AuthGuard} from './auth.guard';
import { SearchComponent } from './search/search.component';
import { ShowSearchComponent } from './show-search/show-search.component';


const routes: Routes = [
  {path:'',redirectTo:'Listcustomer',pathMatch:'full'},
  {path:'Home',redirectTo:'Listcustomer',pathMatch:'full'},
  {path:'Listcustomer', component:CustomerlistComponent},
  {path:'About',component:AboutComponent},
  {path:'Contact',component:ContactComponent},
  {path:'Add',component:AddcustomerComponent,canActivate:[AuthGuard]},
  {path:'Listcustomer/Update/:id',component:UpdatecustomerComponent},
  {path:'Addreactive',component:AddreactiveComponent},
  {path:'login',component:LoginComponent},
  {path:'search',component:SearchComponent},
  {path:'SearchedData',component:ShowSearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
