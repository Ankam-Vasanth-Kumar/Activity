import { MultifierPipe } from './multifier.pipe';

describe('MultifierPipe', () => {
  it('create an instance', () => {
    const pipe = new MultifierPipe();
    expect(pipe).toBeTruthy();
  });
});
