import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multifier'
})
export class MultifierPipe implements PipeTransform {

  transform(value: number, multiply: string): number {
    let mul=parseFloat(multiply);
    return value*mul;
  }

}
