import { Component, OnInit } from '@angular/core';
import { Customer } from '../bean/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  customers:Customer[];
searchItem:string='';
searchedData:Customer[];
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    
    this.customerService.getAllCustomer().subscribe(
      (data:Customer[])=>{this.customers=data;console.log("all"+this.customers)});
  }
  search(value:string){
    this.searchedData=this.customers.filter(customer=>customer.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
    this.customerService.setSearchedData(this.searchedData);
  }

}
