import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../bean/customer';

@Component({
  selector: 'app-show-search',
  templateUrl: './show-search.component.html',
  styleUrls: ['./show-search.component.css']
})
export class ShowSearchComponent implements OnInit {
customer:Customer[];
  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.customer=this.service.getSearchedData();
    
  }

}
