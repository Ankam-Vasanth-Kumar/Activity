import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';

import { Student } from './student/student.interface';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class StudentService {
students:Student[];
  constructor(private http:HttpClient) { }
  ngOnInit(){

  }
  getStudents():Observable<Student[]>{
    return this.http.get<Student[]>("../../assets/student.json");
  }
}
