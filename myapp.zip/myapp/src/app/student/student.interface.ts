export interface Student
{
    id:number;
    age:number;
    gender:string;
    name:string;
    mobile:string;
}