import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentListComponent } from './student/student-list.component';
import { AddStudentComponent } from './student/add-student.component';
import { StartPageComponent } from './student/start-page.component';


const routes: Routes = [
  {path:'student',component:StudentListComponent},
  {path:'Add',component:AddStudentComponent},
  {path:'',component:StartPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
