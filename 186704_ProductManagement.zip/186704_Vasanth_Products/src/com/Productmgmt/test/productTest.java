package com.Productmgmt.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class productTest {
	IProductService obj=new ProductService();
	@Test
	public void testisCategoryValid() {
		boolean res=obj.isCategoryValid("cosmatics");
		assertFalse(res);
	}
	@Test
	public void testisCategoryValid1() {
		boolean res=obj.isCategoryValid("1232435");
		assertTrue(res);
	}

	@Test
	public void testisHikeValid() {
		boolean res=obj.isHikeValid(12);
		assertTrue(res);
	}

	
	


}
