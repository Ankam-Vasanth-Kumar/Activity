package com.cg.productmgmt.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.bean.Products;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {
	String Category;
	int hike;
	IProductService service=new ProductService();
Scanner scanner =new Scanner(System.in);
	static String ch=null;

	public static void main(String[] args) {
		int choice;
		Client clientUI=new Client();
	System.out.println("1.Update Product Price");
	System.out.println("2.Display Product List");
	System.out.println("3.Exit");
	boolean flag = true;
	
	do {
	try {
		Scanner scanner1=new Scanner(System.in);
		choice = scanner1.nextInt();

		switch (choice) {
		case 1:
			clientUI.updateProducts();
			
			break;
		case 2:
			clientUI.displayProducts();
			break;
		
		case 3:System.out.println("Come back Soon..!!");
			System.exit(0);
		default:
			System.out.println("Please enter the  Correct Choice ");
			

		}
		System.out.println("Press Y to continue");
		Scanner scan=new Scanner(System.in);
		ch = scan.nextLine();
		
		
		
		
		
	} catch (InputMismatchException e) {
		System.err.println("Please enter correct only");
	}

	}while(ch.equalsIgnoreCase("y"));

	}

	private void displayProducts() {
		Map<String,Integer>s=service.getProductDetails();
		Iterator<String>it=s.keySet().iterator();
		Iterator<Integer>it1=s.values().iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next()+" =" +it1.next());
		}
		
	}



	private void updateProducts() {
		
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Category");
			Category=scanner.nextLine();
			try {
				flag=service.isCategoryValid(Category);
				
				if(flag)
					throw new ProductException();
			}catch(ProductException e) {
				System.err.println("enter alphabets only");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("enter hike rate");
			hike=scanner.nextInt();
			try {
				flag=service.isHikeValid(hike);
				
				if(!flag)
					throw new ProductException();
			}catch(ProductException e) {
				System.err.println("enter numbers only");
			}
			
		}while(flag);		
		
		Products product=new Products(Category,hike);
		boolean flag1=service.updateProducts(Category,hike);
		
		if(flag1) {
			System.out.println("  Updated successfully");
			

		}
		else
			System.out.println("unable to Update");
		
		
	}

}
