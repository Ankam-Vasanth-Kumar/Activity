package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	static Map<String,String>productDetails;
	static Map<String,Integer>salesDetails;

	static {
		productDetails=new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
	}
	
	
	
	
	
	
	
	
	
	
	@Override
	public boolean updateProducts(String category, int hike) {
		 Iterator<String> iterator1 = productDetails.keySet().iterator();
         Iterator<String> iterator12 = salesDetails.keySet().iterator();
         boolean c=productDetails.containsValue(category);  
         System.out.println("print"+c);
         if(c) {
         while (iterator1.hasNext()) {


                String name = iterator1.next();


                String values=iterator12.next();
                
                
                if(values.equalsIgnoreCase(name)) {
                    
                double price = salesDetails.get(name);
                double price1= price + 0.1 * price;
                salesDetails.replace(name,(int) price1 );
                System.out.println(salesDetails);
                    
                }



         }}
    


      
    
		
		
		
		
		return false;
		
		
	}

	@Override
	public Map<String, Integer> getProductDetails()  {
		return salesDetails;
	}

}
