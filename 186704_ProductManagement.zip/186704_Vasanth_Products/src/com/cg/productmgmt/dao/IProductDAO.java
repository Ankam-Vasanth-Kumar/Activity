package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public interface IProductDAO {
     Map<String,Integer>mp=new HashMap<>();
	boolean updateProducts(String category, int hike) ;
	public Map<String,Integer>getProductDetails();

}
