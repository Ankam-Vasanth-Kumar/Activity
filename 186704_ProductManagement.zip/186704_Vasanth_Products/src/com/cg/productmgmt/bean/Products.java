package com.cg.productmgmt.bean;

public class Products {
	String Category;
	int hike;
	public Products() {
		super();
	}
	public Products(String category, int hike) {
		super();
		Category = category;
		this.hike = hike;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getHike() {
		return hike;
	}
	public void setHike(int hike) {
		this.hike = hike;
	}
	@Override
	public String toString() {
		return "Products [Category=" + Category + ", hike=" + hike + "]";
	}
	
	

}
