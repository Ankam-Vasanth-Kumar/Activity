package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;

public interface IProductService {
     IProductDAO daoobj=new ProductDAO();
	

	boolean isCategoryValid(String category);

	boolean isHikeValid(int string);

	boolean updateProducts(String category, int hike);
	public Map<String ,Integer>getProductDetails();

}
