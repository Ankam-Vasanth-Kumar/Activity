package com.cg.productmgmt.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {

	@Override
	public boolean isCategoryValid(String category) {
		String name1=String.valueOf(category);
		Pattern patternname=Pattern.compile("^[A-Za-z]{1,}$");
		Matcher match=patternname.matcher(name1);
		if(match.matches()) {
			return false;
	}
		return true;
		
		
	}

	@Override
	public boolean isHikeValid(int hike) {
		String mobile=String.valueOf(hike);
		Pattern patternname=Pattern.compile("^[0-9]{23}$");
		Matcher match=patternname.matcher(mobile);
		if(match.matches()) {
			return true;
	}
		return false;
	
	}

	@Override
	public boolean updateProducts(String category, int hike) {
	
			return daoobj.updateProducts(category,hike);
		
		
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		return daoobj.getProductDetails();
		
	}

	
}
