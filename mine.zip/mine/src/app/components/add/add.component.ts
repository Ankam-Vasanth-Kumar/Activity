import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/bean/product';
import { ServicesService } from 'src/app/services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
productData:Product={"id":0,"name":''};
  constructor(private productservice:ServicesService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    console.log("add"+this.productData);
this.productservice.addProduct(this.productData).subscribe((data)=>{this.router.navigate(['Listproduct']);});

  }

}
