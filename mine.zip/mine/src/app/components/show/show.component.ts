import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/bean/product';
import { ServicesService } from 'src/app/services.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
product:Product[];
id:number=123;
name:string="satya";
  constructor(private productservice:ServicesService) { }

  ngOnInit() {
    this.productservice.getAllProduct().subscribe((data:Product[])=>{this.product=data;console.log("all"+this.product)});
  }

}
