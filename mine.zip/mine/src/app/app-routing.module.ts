import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './components/show/show.component';
import { AddComponent } from './components/add/add.component';


const routes: Routes = [
{path:'',redirectTo:'Listproduct',pathMatch:'full'},
{path:'Listproduct',component:ShowComponent},
{path:'Add',component:AddComponent}




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
