import { Injectable } from '@angular/core';
import { Product } from './bean/product';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  
  url:string=" http://localhost:3002/product";
  filteredData:Product[];
    constructor(private http:HttpClient) { }

  addProduct(product:Product){
return this.http.post(this.url,product);
  }
  getAllProduct(){
return this.http.get<Product[]>(this.url);
  }

  
  
}
