package com.cg.eis.pl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class MainClassUI {
	int Empid;
	String name;
	long salary;
	String Designation;
	Scanner scanner=null;
	String scheme;
	static EmployeeService service= new EmployeeServiceImpl();
	static HashMap<Integer, Employee>hmap=new HashMap<>();

	public static void main(String[] args) {
		MainClassUI obj=new MainClassUI();
		Scanner sc=null;
		int option;
		String ch;
		do {
			System.out.println("1.Register Employee\nfind Insurance Scheme\n3.Dispaly Employee Details");
			sc=new Scanner(System.in);
			option=sc.nextInt();
			
			switch(option) {
			case 1:
				obj.register();
				break;
			case 2:
				String name=obj.findScheme();
				System.out.println("Scheme is:"+name);
				break;
			case 3:hmap=service.getEmployeeDetails();
			System.out.println("employee details:\n"+hmap);
			Iterator<Employee>it=hmap.values().iterator();
			while(it.hasNext())
			{
				System.out.println(it.next());
			}
			break;
			
			}
			System.out.println("enter y to continue");
			sc=new Scanner(System.in);
			ch=sc.nextLine();
		}while(ch.equalsIgnoreCase("y"));
	}

	private String findScheme() {
		boolean flag = false;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter salary of the employee");
			salary=scanner.nextInt();
			try {
				flag=service.isSalaryValid(salary);
				
				if(flag)
					throw new EmployeeException();
			}catch(EmployeeException e) {
				System.err.println("Enter Digits only");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Designation");
			Designation=scanner.nextLine();
			try {
				flag=service.isDesignationValid(Designation);
				
				if(flag)
					throw new EmployeeException();
			}catch(EmployeeException e) {
				System.err.println("enter designation properly");
			}
			
		}while(flag);
	String var=service.getScheme(salary,Designation);
		
		return var;
		
		
	}

	private void register() {
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Name");
			name=scanner.nextLine();
			try {
				flag=service.isNameValid(name);
				
				if(flag)
					throw new EmployeeException();
			}catch(EmployeeException e) {
				System.err.println("first letter in the name should be capital throws");
			}
			
		}while(flag);

		
	
	
	
	do {
		scanner=new Scanner(System.in);
		System.out.println("enter Employee ID");
		Empid=scanner.nextInt();
		try {
			flag=service.isEmployeeIDValid(Empid);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("Invalid Emp ID");
		}
		
	}while(flag);
	
	do {
		scanner=new Scanner(System.in);
		System.out.println("enter salary of the employee");
		salary=scanner.nextInt();
		try {
			flag=service.isSalaryValid(salary);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("Enter Digits only");
		}
		
	}while(flag);

	do {
		scanner=new Scanner(System.in);
		System.out.println("enter Designation");
		Designation=scanner.nextLine();
		try {
			flag=service.isDesignationValid(Designation);
			
			if(flag)
				throw new EmployeeException();
		}catch(EmployeeException e) {
			System.err.println("enter designation properly");
		}
		
	}while(flag);
	scheme=service.getScheme(salary,Designation);
	Employee employee=new Employee(Empid,name,salary,Designation,scheme);
	boolean flag1=service.addEmployeeDetails( Empid, employee);
	if(flag1)
		System.out.println("Employee added successfully");
	else
		System.out.println("not Added");

}
		
}