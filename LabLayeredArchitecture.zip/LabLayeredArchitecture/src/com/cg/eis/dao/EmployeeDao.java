package com.cg.eis.dao;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public interface EmployeeDao {
public HashMap<Integer, Employee>empList=new HashMap<>();
	boolean addEmployee(int empid, Employee employee);
	HashMap<Integer, Employee> getDetails();

}
