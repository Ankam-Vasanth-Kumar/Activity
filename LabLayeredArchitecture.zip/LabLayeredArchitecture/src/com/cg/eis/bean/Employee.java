package com.cg.eis.bean;

public class Employee {
private int Empid;
String name;
long Salary;
String Designation;
String nsuranceScheme;
public Employee() {
	super();
}
public Employee(int empid, String name, long salary, String designation, String nsuranceScheme) {
	super();
	Empid = empid;
	this.name = name;
	Salary = salary;
	Designation = designation;
	this.nsuranceScheme = nsuranceScheme;
}
public int getEmpid() {
	return Empid;
}
public void setEmpid(int empid) {
	Empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getSalary() {
	return Salary;
}
public void setSalary(long salary) {
	Salary = salary;
}
public String getDesignation() {
	return Designation;
}
public void setDesignation(String designation) {
	Designation = designation;
}
public String getNsuranceScheme() {
	return nsuranceScheme;
}
public void setNsuranceScheme(String nsuranceScheme) {
	this.nsuranceScheme = nsuranceScheme;
}
@Override
public String toString() {
	return "Employee [Empid=" + Empid + ", name=" + name + ", Salary=" + Salary + ", Designation=" + Designation
			+ ", nsuranceScheme=" + nsuranceScheme + "]";
}

}
