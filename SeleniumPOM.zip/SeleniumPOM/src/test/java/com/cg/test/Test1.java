package com.cg.test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.cg.SeleniumPOM.Main;

public class Test1{
	@Test
	public void login() {
		
		  System.setProperty("webdriver.chrome.driver","C:/BDD933/SeleniumPOM/src/main/java/aa/chromedriver.exe" );
	        WebDriver driver=new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://github.com/login");
	        Main main= new Main(driver);
	        main.typeUsername();
	        main.typePassword();
	        main.signIn();
	}

}
