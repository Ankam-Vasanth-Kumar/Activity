package com.cg.SeleniumPOM;

import javax.sql.rowset.WebRowSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Main {
	
		WebDriver driver;
		By username=By.id("login_field");
		By password=By.xpath("//*[@id=\'password\']");
		By signInButton=By.name("commit");
		public Main(WebDriver driver) {
			this.driver=driver;
		}
		public void typeUsername(){
			driver.findElement(username).sendKeys("vasanthkumar.ankam@gmail.com");
		}
		public void typePassword(){
			driver.findElement(password).sendKeys("Vasanth@123");
		}
		public void signIn(){
			driver.findElement(signInButton).click();
		}
		
		
	

}
