package com.cg.eis.service;

public interface IEmployeeService {

	String getInsurance(int salary, String name);

	boolean isNamevalid(String name);
	boolean isDesignationvalid(String desig);


	
     
}
