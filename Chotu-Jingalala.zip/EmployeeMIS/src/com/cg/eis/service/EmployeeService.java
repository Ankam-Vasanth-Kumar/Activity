package com.cg.eis.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeService implements IEmployeeService {

	@Override
	public String getInsurance(int salary, String design) {
		if((salary>=5000 && salary<20000) && design.equalsIgnoreCase("System Associate" ))
		return "Scheme C";
		else if((salary>=20000 && salary<40000) && design.equalsIgnoreCase("Programmer" ))
			return "Scheme B";
		else if((salary>=40000) && design.equalsIgnoreCase("Manager" ))
			return "Scheme A";
		else if((salary<5000) && design.equalsIgnoreCase("Clerk" ))
			return "No Scheme";
		else
		return "Invalid input";
	}
	@Override
	public boolean isDesignationvalid(String desig) {
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z ]{4,14}$");
		Matcher match = nameptn.matcher(desig);
		if (match.matches()) {
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean isNamevalid(String name) {
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		else
		return false;
	}

	
		
	

}
