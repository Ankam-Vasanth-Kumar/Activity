package com.cg.feedback.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class FeedbackDaoImpl implements IFeedbackDao {

	static Map<String, Integer> mathFeedbackMap=new HashMap<String, Integer>();
	static Map<String, Integer> englishFeedbackMap=new HashMap<String, Integer>();
	static Map<String, Integer> feedbackMap=new HashMap<String, Integer>();
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		if(subject.equalsIgnoreCase("Math")) {
            if(feedbackMap.containsKey(name)) {
                if(rating<feedbackMap.get(name))
                {
                    feedbackMap.put(name, feedbackMap.get(name));
                }
                else {
                    feedbackMap.put(name, rating);
                }
            }
            else {
                feedbackMap.put(name, rating);
            }
            mathFeedbackMap.put(name, rating);
            return mathFeedbackMap;
        }
        else {
            if(feedbackMap.containsKey(name)) {
                if(rating<feedbackMap.get(name)) {
                    feedbackMap.put(name, feedbackMap.get(name));
                }
                else {
                    feedbackMap.put(name, rating);
                }
            }
            else {
                feedbackMap.put(name, rating);
            }
            englishFeedbackMap.put(name, rating);
            return englishFeedbackMap;
        }
        
	}
	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return feedbackMap;
	}
	
	
}
