package com.cg.feedback.dao;

import java.util.Map;

public interface IFeedbackDao {

	Map<String, Integer> addFeedbackDetails(String name,int rating,String subject);
	Map<String, Integer> getFeedbackReport();
	
}
