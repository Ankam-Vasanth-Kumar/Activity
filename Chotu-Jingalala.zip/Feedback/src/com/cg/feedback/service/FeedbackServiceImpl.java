package com.cg.feedback.service;

import java.util.Map;
import java.util.regex.Pattern;
import com.cg.feedback.dao.FeedbackDaoImpl;
import com.cg.feedback.dao.IFeedbackDao;
import com.cg.feedback.exception.FeedbackException;

public class FeedbackServiceImpl implements IFeedbackService {

	IFeedbackDao dao= new FeedbackDaoImpl();
	
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws Exception {
		// TODO Auto-generated method stub
		return dao.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return  dao.getFeedbackReport();
	}
	@Override
	public boolean validateName(String name) throws FeedbackException {

		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{3,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new FeedbackException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	
	@Override
	public boolean validateRating(int rating) throws FeedbackException {

		boolean costFlag = false;

		if (rating < 0 || rating>5) {
			throw new FeedbackException("rating should not be lt 0 and gt 5");
		} else {
			costFlag = true;
		}
		return costFlag;

	}

	
}
