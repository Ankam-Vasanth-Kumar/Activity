import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.feedback.bean.Feedback;
import com.cg.feedback.dao.FeedbackDaoImpl;
import com.cg.feedback.dao.IFeedbackDao;

class FeedbackTest {

	static IFeedbackDao dao=null;
	Feedback feedback;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new FeedbackDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@BeforeEach
	void setUp() throws Exception {
		feedback=new Feedback("Bhavya",4,"Math");
	}

	@AfterEach
	void tearDown() throws Exception {
		feedback=null;
	}

	@Test
	void testAddFeedbackDetails() {
		assertEquals(1, dao.addFeedbackDetails("Bhavya",4,"Math").size());
	}

	@Test
	void testGetFeedbackReport() {
		assertTrue(dao.getFeedbackReport().size()>0);
		
	}

}
