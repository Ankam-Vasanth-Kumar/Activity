package Db;

public class Customer {

}
