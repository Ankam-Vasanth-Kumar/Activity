package Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DMLOperation {

	Scanner scanner=new Scanner(System.in);
		Connection connection=null;
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		boolean status=false;
		int row=-1;
		
		public void create(){
			String query="create table trainee(tid number(5) primary key," +"name varchar2(25),marks number(7,2))";
			try {
				statement=connection.prepareStatement(query);
				status=statement.execute();
				System.out.println("Table created:"+status);
			} catch (SQLException e) {
			e.printStackTrace();
			}
			
		}
		public void insert() {
		    try {
		        System.out.println("Enter tid, name, marks");
		        int tid=scanner.nextInt();
		        String name=scanner.next();
		        double marks=scanner.nextDouble();
		        connection=DBCconnection.getConnection();
		        
		        statement=connection.prepareStatement("insert into trainee values(?,?,?)");
		        statement.setInt(1, tid);
		        statement.setString(2, name);
		        statement.setDouble(3, marks);
		        row=statement.executeUpdate();
		        System.out.println(row+" inserted");
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

		 

		public void update() {
		    try {
		        System.out.println("Enter tid to update");
		        int tid=scanner.nextInt();
		        System.out.println("Enter the new marks");
		        double marks=scanner.nextDouble();
		        connection=DBCconnection.getConnection();
		        
		        statement=connection.prepareStatement("update trainee set marks=? where tid=?");
		        statement.setDouble(1, marks);
		        statement.setInt(2, tid);
		        row=statement.executeUpdate();
		        System.out.println(row+" update");
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

		 


		public void delete() {
		    try {
		        System.out.println("Enter tid to delete");
		        int tid=scanner.nextInt();
		        connection=DBCconnection.getConnection();
		        statement=connection.prepareStatement("delete from trainee where tid=?");
		        statement.setDouble(1, tid);
		        row=statement.executeUpdate();
		        System.out.println(row+" delete");
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}
		public static void main(String[] args) {
	     DMLOperation dml=new DMLOperation();
	 //    dml.create();
	     Scanner scanner=new Scanner(System.in);
	     System.out.println("Enter 1.insert \n 2.Update \n 3.delete \n 4.ViewAll \n 5.ViewById");
	     int option=scanner.nextInt();
	     switch(option)
	     {
	     case 1:dml.insert();break;
	     case 2:dml.update();break;
	     case 3:dml.delete();break;
	     
	     default:System.out.println("Enter 1 to 5 only");break;
	     
	     }
		}

}
