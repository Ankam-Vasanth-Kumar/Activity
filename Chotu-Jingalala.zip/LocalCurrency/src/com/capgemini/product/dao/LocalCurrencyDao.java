package com.capgemini.product.dao;

import java.util.HashMap;

import java.util.Map;

import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;

public interface LocalCurrencyDao {
	
	Map<Integer, Product> map=new HashMap<>();

	int addProduct(Product product)throws LCException;

	double getPriceInINR(double productPrice, int productQuantity)throws LCException;

	double getConversionCharge(double productPrice)throws LCException;

	Map<Integer, Product> getAllProducts() throws LCException;

	boolean updateProduct(int id, Product products)throws LCException;

	boolean deleteItem(int id);

	Product viewById(int custId);

}
