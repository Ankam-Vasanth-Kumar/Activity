package com.capgemini.product.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.product.Exception.LCException;
import com.capgemini.product.bean.Product;
import com.capgemini.product.dao.LocalCurrencyDao;
import com.capgemini.product.dao.LocalCurrencyDaoImpl;

public class LocalCurrencyServiceImpl implements LocalCurrencyService {
	
	LocalCurrencyDao dao=new LocalCurrencyDaoImpl();

	@Override
	public boolean isNameValid(String productName) throws LCException {
		String regEx="^[A-Z]{1}[a-zA-Z ]{4,}$";
		boolean nameFlag =false;
		if(!Pattern.matches(regEx, productName)) {
			throw new LCException("start with capital letter and followed by 4 characters");
		}
		else
			nameFlag=true;
		return nameFlag;
	}

	@Override
	public boolean isPriceValid(double productPrice) throws LCException {
		boolean priceFlag=false;
		if(productPrice<1000) {
			throw new LCException("cost should be greater than 1000");
			}
		else
			priceFlag=true;
		return priceFlag;
	}

	@Override
	public boolean isQuantityValid(int productQuantity) throws LCException {
		boolean quantityFlag=false;
		if(productQuantity<1) {
			throw new LCException("quantity should be greater than 1");
		}
		else
			 quantityFlag=true;
			 
		return quantityFlag;
	}

	@Override
	public int addProduct(Product product) throws LCException {	
		return dao.addProduct(product);
	}

	

	@Override
	public double getPriceInINR(double productPrice, int productQuantity) throws LCException {
		return dao.getPriceInINR(productPrice,productQuantity);
	}

	@Override
	public double getConversionCharge(double productPrice) throws LCException {
		return dao.getConversionCharge(productPrice);
	}

	@Override
	public List<Product> getAllProducts() throws LCException {
		List<Product> list  =new  ArrayList<Product>();
		Collection<Product> col = dao.getAllProducts().values();
		list.addAll(col);
		return list;
	}

	@Override
	public boolean updateProduct(int id,Product products) throws LCException {
		
		return dao.updateProduct(id,products);
		
		
	}

	@Override
	public boolean delete(int id) {
	
		return dao.deleteItem(id);
	}

	@Override
	public Product viewById(int custId) {
	
		return dao.viewById(custId);
	}

}
