package om.capgemini.BankApplication.UI;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.BankApplication.Exception.BankApplicationException;
import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.service.BankService;
import com.capgemini.BankApplication.service.BankServiceImpl;
public class UIClass {
	Scanner scanner=new Scanner(System.in);
	BankService service=new BankServiceImpl();
	long accountNo=0;
	HashMap<Long, Account>list=new HashMap<>();
	HashMap<Long, Account>list2=new HashMap<>();
	
private void Login() {
		String name;
		String password2;
		list=service.getAccountDetails();
		list2=service.getAccountDetails();
		Iterator<Account>it=list.values().iterator();
		Iterator<Account>it2=list.values().iterator();
		System.out.println(list);
		System.out.println(list2);
		System.out.println("enter name ");
		name=scanner.next();
System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
			System.out.println(list.containsValue("Vasanth"));
		}
		
	
	private void Register() {
		String uname,password,address,mobileNo;
		long aadhrCardNo;
		boolean flag=true;
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter Name");
			uname=scanner.nextLine();
			try {
				flag=service.isNameValid(uname);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("first letter in the name should be capital throws");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("set Password");
			password=scanner.nextLine();
			try {
				flag=service.isPasswordValid(password);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);		
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter address");
			address=scanner.nextLine();
			try {
				flag=service.isAddressValid(address);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("use numbers and alphabets only");
			}
			
		}while(flag);

		do {
			scanner=new Scanner(System.in);
			System.out.println("enter mobile number");
			mobileNo=scanner.nextLine();
			try {
				flag=service.isMobileValid(mobileNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("enter aadhar number");
			aadhrCardNo=scanner.nextLong();
			try {
				flag=service.isAadharValid(aadhrCardNo);
				
				if(flag)
					throw new BankApplicationException();
			}catch(BankApplicationException e) {
				System.err.println("enters numbers only");
			}
			
		}while(flag);
		
		long accountNo=(long)(Math.random()*1000000000);
	
		Account account=new Account(uname,password,address,mobileNo,aadhrCardNo,0,accountNo);
		boolean flag1=service.addAccount(account);
		if(flag1)
			System.out.println("  account created successfully");
		else
			System.out.println("unable to create account");
		
	}

	public static void main(String[] args) {
		UIClass clientUI = new UIClass();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Welcome to the Bank Management System");
		int choice = 2;
		boolean flag = true;
		String ch = null;
        do {
		System.out.println(" 1.Register \n2.Login\n0.Exit");
		try {
			Scanner scanner1=new Scanner(System.in);
			choice = scanner1.nextInt();

			switch (choice) {
			case 1:
				clientUI.Register();
				flag=false;
				break;
			case 2:
				clientUI.Login();
				flag=false;
				break;
			case 0:System.out.println("Come back Soon..!!");
				System.exit(0);
			default:
				System.out.println("Please enter the  Correct Choice ");
				flag=true;

			}
			System.out.println("Press Y to continue");
			ch = scanner.nextLine();
			
			
		} catch (InputMismatchException e) {
			System.err.println("Please enter 1 or 0 only");
		}
        }while(ch.equalsIgnoreCase("y"));

	}

	

	
}
