package com.capgemini.BankApplication.bean;

public class Account {
	String uname,password,address,mobileNo;
	long aadhrCardNo;
	long balance=0,accountNo;
	public Account() {
		super();
	}
	public Account(String uname, String password, String address, String mobileNo, long aadhrCardNo, long balance,
			long accountNo) {
		super();
		this.uname = uname;
		this.password = password;
		this.address = address;
		this.mobileNo = mobileNo;
		this.aadhrCardNo = aadhrCardNo;
		this.balance = balance;
		this.accountNo = accountNo;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public long getAadhrCardNo() {
		return aadhrCardNo;
	}
	public void setAadhrCardNo(long aadhrCardNo) {
		this.aadhrCardNo = aadhrCardNo;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "Account [uname=" + uname + ", password=" + password + ", address=" + address + ", mobileNo=" + mobileNo
				+ ", aadhrCardNo=" + aadhrCardNo + ", balance=" + balance + ", accountNo=" + accountNo + "]";
	}
	
}
