package com.capgemini.BankApplication.dao;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;

public interface Bankdao {
       HashMap<Long, Account>accountsList=new HashMap<>();
       
	boolean addingAccount(Account account);

	HashMap<Long, Account> getDetails();

}
