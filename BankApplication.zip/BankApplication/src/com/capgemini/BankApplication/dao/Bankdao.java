package com.capgemini.BankApplication.dao;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;

public interface Bankdao {
	HashMap<Long, Transaction>translist=new HashMap<>();
       HashMap<Long, Account>accountsList=new HashMap<>();
       HashMap<String, String>accountcheck=new HashMap<>();
       HashMap<Long, Long>showbalance=new HashMap<>();
       
	boolean addingAccount(Account account);

	HashMap<Long, Account> getDetails();

	HashMap<String, String> getunamePassword();

	HashMap<Long, Long> getBalance();

	boolean addtransaction(Transaction transaction);

	HashMap<Long, Transaction> getTransaction();

}
