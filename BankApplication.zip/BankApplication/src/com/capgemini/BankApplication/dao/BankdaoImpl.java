package com.capgemini.BankApplication.dao;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;

public class BankdaoImpl implements Bankdao {

	@Override
	public boolean addingAccount(Account account) {
	   accountsList.put(account.getAccountNo(),account);
	 
		return true;
	}

	@Override
	public HashMap<Long, Account> getDetails() {
		return accountsList;
	}

}
