package com.capgemini.BankApplication.dao;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;

public class BankdaoImpl implements Bankdao {

	@Override
	public boolean addingAccount(Account account) {
	   accountsList.put(account.getAccountNo(),account);
	 accountcheck.put(account.getUname(), account.getPassword());
	 showbalance.put(account.getAccountNo(), account.getBalance());
		return true;
	}

	@Override
	public HashMap<Long, Account> getDetails() {
		return accountsList;
	}

	@Override
	public HashMap<String, String> getunamePassword() {
	
		return accountcheck;
	}

	@Override
	public HashMap<Long, Long> getBalance() {
		return showbalance;
		
	}

	@Override
	public boolean addtransaction(Transaction transaction) {
		translist.put(transaction.getToAccountNo(), transaction);
		return true;
	}

	@Override
	public HashMap<Long, Transaction> getTransaction() {
		return translist;
	}

}
