package com.cg.SeliniumPOM2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test1 {
	@Test
	public void login() {
		  System.setProperty("webdriver.chrome.driver","C:/BDD933/SeliniumPOM2/src/main/java/aa/chromedriver.exe" );
	        WebDriver driver=new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("http://demosite.center/wordpress/wp-login.php");
	        Main main= new Main(driver);
	        main.typeUsername();
	        main.typePassword();
	        main.signIn();
	}

}
