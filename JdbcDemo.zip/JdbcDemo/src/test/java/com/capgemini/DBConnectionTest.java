package com.capgemini;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.utility.DBConnection;

class DBConnectionTest {

	@Test
	void testGetConnection() {
		assertNotNull(DBConnection.getConnection());
	}

}
