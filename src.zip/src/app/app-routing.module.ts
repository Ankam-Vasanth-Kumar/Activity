import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchedproductsComponent } from './searchedproducts/searchedproducts.component';
import { ShowproductsComponent } from './showproducts/showproducts.component';


const routes: Routes = [
   {path:'',component:SearchedproductsComponent},
  {path:"search",component:SearchedproductsComponent},
  {path:"products",component:ShowproductsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
