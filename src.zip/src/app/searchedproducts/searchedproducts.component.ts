import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { Products } from '../products';

@Component({
  selector: 'app-searchedproducts',
  templateUrl: './searchedproducts.component.html',
  styleUrls: ['./searchedproducts.component.css']
})
export class SearchedproductsComponent implements OnInit {
  products:Products[];
  constructor(private studentservice:ProductserviceService) { }

  ngOnInit() {
  }
  searchedproduct(data){
    console.log(data);
    this.products=this.studentservice.getData().filter(s=>s.name==data.name||s.category==data.name);
  }


}
