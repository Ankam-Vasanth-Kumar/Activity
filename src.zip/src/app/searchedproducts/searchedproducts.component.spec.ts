import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchedproductsComponent } from './searchedproducts.component';

describe('SearchedproductsComponent', () => {
  let component: SearchedproductsComponent;
  let fixture: ComponentFixture<SearchedproductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchedproductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchedproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
