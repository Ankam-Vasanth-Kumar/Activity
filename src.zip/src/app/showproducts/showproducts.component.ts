import { Component, OnInit } from '@angular/core';
import { Products } from '../products';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-showproducts',
  templateUrl: './showproducts.component.html',
  styleUrls: ['./showproducts.component.css']
})
export class ShowproductsComponent implements OnInit {
  product:Products[];
  constructor(private prodductservice:ProductserviceService) { }

  ngOnInit() {
    if (!this.prodductservice.getData()) {
      this.prodductservice.getProducts().subscribe(data => {
        this.product = data;
        this.prodductservice.setProducts(this.product);
        console.log(this.product);
       });
    }
    else {
      this.product = this.prodductservice.getData();
    }

  }

  onClick(id:string){
    this.prodductservice.deleteProduct(id);
   this.product=this.prodductservice.getData();
  }

}
