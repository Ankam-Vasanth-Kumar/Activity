import { Injectable } from '@angular/core';
import { Products } from './products';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {


  constructor(private http:HttpClient) { }
students:Products[];
  getProducts():Observable<Products[]>
  {
    return this.http.get<Products[]>("../../assets/db.json");
  }
  
  getData(){
    return this.students;
  }
 
  setProducts(student:Products[]){
    
    this.students=student;
  }
  deleteProduct(id:string){
    this.students=this.students.filter(e=>e.id!=id);
  }

}
