import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import{ HttpClientModule} from '@angular/common/http';
import { from } from 'rxjs';

import{FormsModule} from '@angular/forms';
import { SearchedproductsComponent } from './searchedproducts/searchedproducts.component';
import { ShowproductsComponent } from './showproducts/showproducts.component';
import { ProductserviceService } from './productservice.service';

@NgModule({
  declarations: [
    AppComponent,
    SearchedproductsComponent,
    ShowproductsComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
   
  ],
  providers: [ProductserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
