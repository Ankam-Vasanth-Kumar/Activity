export class Products {
    id:string;
    name:string;
    price:number;
    category:string;
}
