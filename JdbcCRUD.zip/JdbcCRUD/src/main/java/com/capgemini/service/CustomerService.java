package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Customer;

public interface CustomerService {

	int insertCustomer(Customer customer);

	boolean updateCustomer(Customer customer);

	boolean removeCustomer(int custID);

	Customer viewById(int custId);

	List<Customer> viewAll();

	
}
