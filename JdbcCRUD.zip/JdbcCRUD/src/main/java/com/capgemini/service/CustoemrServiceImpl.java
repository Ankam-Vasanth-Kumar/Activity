package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Customer;
import com.capgemini.dao.CustomerDao;
import com.capgemini.dao.CustomerDaoImpl;


/**
 * 
 * @author kirankpa
 * @version 1.0
 * 
 *
 */
public class CustoemrServiceImpl implements CustomerService {
	boolean status=false;
	int row=-1;
	CustomerDao customerDao=new CustomerDaoImpl();
	@Override
	public int insertCustomer(Customer customer) {
		row=customerDao.insertCustomer(customer);
		if(row>0)
			status=true;
		return row;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		row=customerDao.updateCustomer(customer);
		if(row>0)
			status=true;
		
		return status;
	}

	@Override
	public boolean removeCustomer(int custID) {
		row=customerDao.deleteCustomer(custID);
		if(row>0)
			status=true;
		
		return status;
		}

	@Override
	public Customer viewById(int custId) {
		return customerDao.getById(custId);

	}

	@Override
	public List<Customer> viewAll() {
   return customerDao.viewAll();

	}

	

}
