package com.capgemini.MainUI;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustoemrServiceImpl;
import com.capgemini.service.CustomerService;

public class MainUi {
	private static boolean status;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		CustomerService service = new CustoemrServiceImpl();
		
		while (true) {
			try {
				System.out.println("1.register \n2.Update \n3.Delete \n4.View \n5.ViewAll");
				int choice = scanner.nextInt();
				
				switch (choice) {
				
				case 1: {
					System.out.println("Enter name,address,phone");
					String name = scanner.next();
					String address = scanner.next();
					long phone = scanner.nextLong();
					System.out.println("Enter DOB format should be dd-MM-yy");
					String dob = scanner.next();
					SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yy");

					Date d = sf.parse(dob);
					Customer customer = new Customer(0, name, address, d, phone);
					int custId = service.insertCustomer(customer);
					if (custId > 0)
						System.out.println("Customer Registererd successfully and your id is :" + custId);
					else
						System.out.println("Not registered try again..");
				}
				break;
				
				case 2:{
					System.out.println("Enter CustId to update");
					int custid=scanner.nextInt();
					System.out.println("Enter name,address,phone");
					String name = scanner.next();
					String address = scanner.next();
					long phone = scanner.nextLong();
					System.out.println("Enter DOB format should be dd-MM-yy");
					String dob = scanner.next();
					SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yy");
					Date d = sf.parse(dob);
					Customer customer = new Customer(0, name, address, d, phone);
					status = service.updateCustomer(customer);
					if (status)
						System.out.println("Customer Updated Successfully" );
					else
						System.out.println("Not registered try again..");
				}
				break;
				
				case 3:{System.out.println("Enter CustId to delete");
				int custid=scanner.nextInt();
				status=service.removeCustomer(custid);
				if(status)
					System.out.println("Customer deleted successfully");
				else
					System.out.println("Not registered yet. Try again..");
					
				}break;
				
				case 4: {
					System.out.println("Enter CustId to View");
					int custid=scanner.nextInt();
					Customer customer=new Customer();
					customer=service.viewById(custid);
					System.out.println(customer);
				}break;
				
				case 5:
				{

					List<Customer> list=new ArrayList<>();
					list=service.viewAll();
					
					Iterator<Customer> iterator=list.iterator();
					while(iterator.hasNext())					
					System.out.println(iterator.next());
				}break;
				
				default:
					System.out.println("Enter 0-5 only");
					break;
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}

		}
	}

}
