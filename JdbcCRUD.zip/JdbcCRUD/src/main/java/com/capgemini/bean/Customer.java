package com.capgemini.bean;

import java.io.Serializable;
import java.util.Date;



public class Customer implements Serializable {
	private static final long serialVersionUID= 1L;
	
	private int custId;/*create table customer(custid number(5) primary key,
			             2  name varchar(25),
			             3  address varchar(30),
			             4  dob date,
			             5  phone number(10));*/
	private String name;
	private String Address;                   //create sequence customerseq start with 4000;
	private Date dob;
	private long phone;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Customer(int custId, String name, String address, Date dob, long phone) {
		super();
		this.custId = custId;
		this.name = name;
		Address = address;
		this.dob = dob;
		this.phone = phone;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "\ncustId=" + custId + ", name=" + name + ", Address=" + Address + ", dob=" + dob + ", phone="
				+ phone + "]";
	}
	
	
	
}
