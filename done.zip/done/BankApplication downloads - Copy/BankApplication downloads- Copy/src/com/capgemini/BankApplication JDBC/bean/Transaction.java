package com.capgemini.BankApplication.bean;

import java.time.LocalDate;
import java.util.Date;

public class Transaction {
	long fromAccountNo;
	long toAccountNo;
	int Tid; 
	
	LocalDate date=LocalDate.now();
	String transactionType="Debit";
	long money;
	public Transaction() {
		super();
	}
	public Transaction(long fromAccountNo, long toAccountNo, LocalDate date, String transactionType, long money,int Tid) {
		super();
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
		this.date = date;
		this.transactionType = transactionType;
		this.money = money;
		this.Tid=Tid;
	}
	
	public long getFromAccountNo() {
		return fromAccountNo;
	}
	public void setFromAccountNo(long fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}
	public long getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	public int getTid() {
		return Tid;
	}
	public void setTid(int tid) {
		Tid = tid;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public long getMoney() {
		return money;
	}
	public void setMoney(long money) {
		this.money = money;
	}
	@Override
	public String toString() {
		return Tid+"              "+fromAccountNo + "              " + toAccountNo + "         " + date
				+ "         " + transactionType + "             " + money ;
	}
	
	
	
}
