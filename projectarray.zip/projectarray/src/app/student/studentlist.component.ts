import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
  students: IStudent[];

  constructor(private studentservice: StudentService) { }

  ngOnInit() {
    if (!this.studentservice.getData()) {
      this.studentservice.getStudents().subscribe(data => {
        this.students = data;
        this.studentservice.setStudents(this.students);
       });
    }
    else {
      this.students = this.studentservice.getData();
    }
  }
  onClick(id:number){
    this.studentservice.deleteStudent(id);
   this.students=this.studentservice.getData();
  }

updates(student:IStudent,i:number){
this.studentservice.updatingStudent(student);
this.students.splice(i,1);

}
  

}
