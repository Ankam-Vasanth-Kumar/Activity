import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IStudent } from './student.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  updatingStudent(student: IStudent) {
   
    this.students=this.students.filter(e=>e.id==student.id);

  }

  constructor(private http:HttpClient) { }
students:IStudent[];
  getStudents():Observable<IStudent[]>
  {
    return this.http.get<IStudent[]>("../../assets/student.json");
  }
  
  getData(){
    return this.students;
  }
  addStudent(student:IStudent){
  this.students.push(student);
  }
  setStudents(student:IStudent[]){
    
    this.students=student;
  }
  
  deleteStudent(id:number){
    this.students=this.students.filter(e=>e.id!=id);
  }
updateS(){
  return this.students;
}
}
