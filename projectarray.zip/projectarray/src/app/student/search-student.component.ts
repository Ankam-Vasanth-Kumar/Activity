import { Component, OnInit } from '@angular/core';
import { IStudent } from './student.interface';
import { StudentService } from './student.service';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
   students:IStudent[];
  constructor(private studentservice:StudentService) { }

  ngOnInit() {
  }

  searchStudent(data){
    console.log(data);
    this.students=this.studentservice.getData().filter(s=>s.name==data.name);
  }

}
