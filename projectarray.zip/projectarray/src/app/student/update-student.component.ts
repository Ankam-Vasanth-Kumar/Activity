import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { Router, ActivatedRoute } from '@angular/router';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
  students:IStudent[];
  constructor(private studentservice:StudentService,private route:Router,private router:ActivatedRoute) { }
student:IStudent[];
  ngOnInit() {
   this.student= this.studentservice.updateS();
  }
  updateStudent(student:IStudent){
    
  }

  

}
