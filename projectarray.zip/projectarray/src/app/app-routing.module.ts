import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentlistComponent } from './student/studentlist.component';
import { AddstudentComponent } from './student/addstudent.component';
import { StartpageComponent } from './student/startpage.component';
import { SearchStudentComponent } from './student/search-student.component';
import { UpdateStudentComponent } from './student/update-student.component';


const routes: Routes = [
 
{path:"students",component:StudentlistComponent},
{path:"add",component:AddstudentComponent},
{path:'',component:StartpageComponent},
{path:"search",component:SearchStudentComponent},
{path:'students/update/:id',component:UpdateStudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
