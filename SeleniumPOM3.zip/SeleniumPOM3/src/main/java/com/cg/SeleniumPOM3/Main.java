package com.cg.SeleniumPOM3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Main {
	WebDriver driver;
	By username=By.id("userName");
	By password=By.xpath("//*[@id=\'password\']");
	By signInButton=By.id("loginButton");
	public Main(WebDriver driver) {
		this.driver=driver;
	}
	public void typeUsername(){
		driver.findElement(username).sendKeys("satyadv");
	}
	public void typePassword(){
		driver.findElement(password).sendKeys("India@1234");
	}
	public void signIn(){
		driver.findElement(signInButton).click();
	}


}
